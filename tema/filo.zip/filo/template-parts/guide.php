<?php
/**
 * Bottega aperta: le guide, cioè gli articoli nella categoria «Attrezzi».
 * Finché non ce n'è nessuna pubblicata, si vede la prima come «in preparazione».
 *
 * @package Filo
 */

$filo_g = filo_guide_query( 12 );
$filo_card = 'display: flex; flex-direction: column; gap: 14px; background: var(--card); border: 1px solid var(--line); padding: 28px 28px 32px';
?>
<section style="border-top: 1px solid var(--ink); padding: 48px 0 72px">
<p class="m" style="margin: 0 0 32px; color: var(--mute)"><?php echo $filo_g->found_posts > 1 ? 'Guide' : 'Guida'; ?></p>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px; max-width: <?php echo $filo_g->found_posts > 1 ? '1120px' : '560px'; ?>">
<?php if ( $filo_g->have_posts() ) : ?>
	<?php
	while ( $filo_g->have_posts() ) :
		$filo_g->the_post();
		?>
<a href="<?php the_permalink(); ?>" style="<?php echo esc_attr( $filo_card ); ?>">
<span class="m" style="color: var(--accent)">Guida</span>
<span class="h" style="font-size: 30px; font-weight: 600; line-height: 1.05"><?php the_title(); ?></span>
<?php if ( has_excerpt() ) : ?><span style="font-size: 18px; line-height: 1.5"><?php echo esc_html( get_the_excerpt() ); ?></span><?php endif; ?>
<span class="m" style="border-bottom: 1px solid currentColor; align-self: flex-start; padding-bottom: 2px">Leggi la guida</span>
</a>
	<?php endwhile; ?>
	<?php wp_reset_postdata(); ?>
<?php else : ?>
<div style="<?php echo esc_attr( $filo_card ); ?>">
<span class="m" style="color: var(--accent)">Guida · in preparazione</span>
<span class="h" style="font-size: 30px; font-weight: 600; line-height: 1.05">Come curare<br>la tua scheda Google</span>
<span style="font-size: 18px; line-height: 1.5">La prima cosa che vede chi ti cerca, spesso prima del sito. Dentro: categoria e orari, festivi compresi, le foto che funzionano, come chiedere le recensioni e come rispondere, anche a quelle storte.</span>
<span class="m" style="color: var(--mute)">Arriva a breve</span>
</div>
<?php endif; ?>
</div>
</section>
