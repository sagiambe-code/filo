<?php
/**
 * Home: l'ultimo racconto pubblicato. Se non ce ne sono, la sezione non compare.
 *
 * @package Filo
 */

$filo_r = new WP_Query(
	array(
		'post_type'      => 'racconto',
		'posts_per_page' => 1,
	)
);
if ( ! $filo_r->have_posts() ) {
	return;
}
$filo_r->the_post();
$filo_meta = array_filter( array( get_post_meta( get_the_ID(), 'filo_cliente', true ), get_post_meta( get_the_ID(), 'filo_lavoro', true ) ) );
$filo_cap  = get_post_meta( get_the_ID(), 'filo_didascalia', true );
?>
<section id="lavori" style="border-top: 1px solid var(--ink); padding: 56px 0 72px">
<div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: baseline; gap: 16px; margin-bottom: 48px">
<h2 class="h" style="margin: 0; font-size: clamp(36px, 5vw, 64px); line-height: .95; font-weight: 600">Lavori,<br>raccontati</h2>
<a href="<?php echo esc_url( get_post_type_archive_link( 'racconto' ) ); ?>" class="m" style="color: var(--mute)">Non una vetrina, delle storie</a>
</div>
<article style="display: flex; flex-wrap: wrap; gap: 40px 64px; align-items: center">
<?php if ( has_post_thumbnail() ) : ?>
<figure class="polaroid" style="flex: 1 1 320px; max-width: 480px; transform: rotate(-1.2deg)">
<?php the_post_thumbnail( 'filo-polaroid', array( 'loading' => 'lazy' ) ); ?>
<?php if ( $filo_cap ) : ?><figcaption><?php echo esc_html( $filo_cap ); ?></figcaption><?php endif; ?>
</figure>
<?php endif; ?>
<div style="flex: 1 1 360px; min-width: 0">
<?php if ( $filo_meta ) : ?><p class="m" style="margin: 0 0 14px; color: var(--mute)"><?php echo esc_html( implode( ' · ', $filo_meta ) ); ?></p><?php endif; ?>
<h3 class="h" style="margin: 0 0 16px; font-size: clamp(30px, 3.4vw, 44px); line-height: 1.02; font-weight: 600"><?php the_title(); ?></h3>
<?php if ( has_excerpt() ) : ?><p style="margin: 0 0 22px; font-size: 19px; line-height: 1.55"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
<a href="<?php the_permalink(); ?>" class="m" style="border-bottom: 1px solid currentColor; padding-bottom: 2px">Leggi il racconto</a>
</div>
</article>
<p style="margin: 56px 0 0; text-align: center; font-style: italic; font-size: 20px; color: var(--mute)">Il prossimo racconto potrebbe essere il tuo. <a href="#scrivimi" style="font-style: normal; border-bottom: 1px solid var(--accent)">Scrivi alla bottega</a></p>
</section>
<?php
wp_reset_postdata();
