<?php
/**
 * Pagina «Chi c’è dietro».
 *
 * @package Filo
 */

get_header();
?>
<section style="padding: clamp(48px, 8vw, 104px) 0 clamp(40px, 6vw, 64px)">
<p class="m" style="margin: 0 0 24px; color: var(--mute)">Chi c’è dietro</p>
<h1 class="h" style="margin: 0; font-size: clamp(44px, 6.4vw, 92px); line-height: .92; font-weight: 600; letter-spacing: -.045em">Il codice è<br>metà della storia.</h1>
</section>

<section style="border-top: 1px solid var(--ink); padding: 56px 0 80px; display: flex; flex-wrap: wrap; gap: 48px 72px; align-items: flex-start">
<div style="flex: 999 1 520px; min-width: 0; max-width: 680px">
<p style="margin: 0 0 26px; font-size: clamp(21px, 2vw, 25px); line-height: 1.5">Sono Salvatore, sono nato a Palermo, e oggi vivo nella punta della Sicilia, dove le Egadi si vedono dalla finestra.</p>
<p style="margin: 0 0 26px; font-size: 20px; line-height: 1.6">Sono un informatico prestato alla vendita: da anni curo i siti e l’e-commerce di aziende, tra cataloghi, schede prodotto in più lingue, prezzi che devono tornare, clienti che scrivono da mezzo mondo e spedizioni che devono arrivare intere. È lì che ho imparato che un sito non è finito quando funziona, ma quando qualcuno trova quello che cerca senza dover telefonare.</p>
<p style="margin: 0 0 26px; font-size: 20px; line-height: 1.6">Poi c’è l’altra metà, quella che in ufficio non si vede: leggo molto, scrivo una newsletter, fotografo quello che incontro, e ho imparato che le parole giuste fanno lo stesso lavoro del codice buono, tengono in piedi le cose senza farsi notare.</p>
<p style="margin: 0; font-size: 20px; line-height: 1.6">Filo nasce quando le due metà finiscono sullo stesso tavolo. È una bottega piccola e lo resterà: dietro ogni sito ci sono persone, che rispondono alle mail, bevono il caffè con te e alla fine ti consegnano le chiavi.</p>
</div>
<div style="flex: 1 1 280px; max-width: 360px; display: flex; flex-direction: column; gap: 40px">
<figure style="margin: 0; background: var(--frame); padding: 12px 12px 0; box-shadow: 0 1px 2px rgba(0,0,0,.08), 0 10px 30px rgba(0,0,0,.09); transform: rotate(1.8deg)">
<?php $filo_ritratto = get_posts( array( 'post_type' => 'attachment', 'name' => 'salvatore', 'posts_per_page' => 1 ) ); $filo_ritratto_src = $filo_ritratto ? wp_get_attachment_image_url( $filo_ritratto[0]->ID, 'large' ) : get_template_directory_uri() . '/assets/img/salvatore.jpg'; ?>
<img src="<?php echo esc_url( $filo_ritratto_src ); ?>" alt="Salvatore Giambelluca, in giacca e camicia nere, davanti a un muro grigio" width="640" height="800" style="display: block; width: 100%; height: auto; aspect-ratio: 4 / 5; object-fit: cover; background: var(--ph)">
<figcaption style="font-style: italic; font-size: 16px; color: #3A3732; padding: 14px 4px 18px">Vestito come l’inchiostro. La lampadina è fuori campo.</figcaption>
</figure>
<dl style="margin: 0; display: flex; flex-direction: column; gap: 18px">
<div style="border-top: 1px solid var(--line); padding-top: 12px">
<dt class="m" style="color: var(--mute); margin-bottom: 6px">Il banco</dt>
<dd style="margin: 0; font-size: 18px; line-height: 1.45">Sicilia. Si lavora anche a distanza.</dd>
</div>
<div style="border-top: 1px solid var(--line); padding-top: 12px">
<dt class="m" style="color: var(--mute); margin-bottom: 6px">Gli attrezzi</dt>
<dd style="margin: 0; font-size: 18px; line-height: 1.45">WordPress, Google, un editor di testo, una macchina fotografica.</dd>
</div>
<div style="border-top: 1px solid var(--line); padding-top: 12px">
<dt class="m" style="color: var(--mute); margin-bottom: 6px">Sul comodino</dt>
<dd style="margin: 0; font-size: 18px; line-height: 1.45; font-style: italic">[Due o tre libri del momento.]</dd>
</div>
</dl>
</div>
</section>

<section aria-labelledby="penso" style="border-top: 1px solid var(--ink); padding: 48px 0 80px">
<h2 id="penso" class="m" style="margin: 0 0 32px; color: var(--mute); font-weight: 400">Come la penso</h2>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 40px 56px">
<div style="border-top: 2px solid var(--ink); padding-top: 18px">
<h3 class="h" style="margin: 0 0 10px; font-size: 26px; font-weight: 600; line-height: 1.1">Capire prima di disegnare</h3>
<p style="margin: 0; font-size: 18px; line-height: 1.55">Prima di aprire il computer si ascolta: chi sei, a chi parli, cosa deve succedere dopo che qualcuno ha letto la tua pagina.</p>
</div>
<div style="border-top: 2px solid var(--ink); padding-top: 18px">
<h3 class="h" style="margin: 0 0 10px; font-size: 26px; font-weight: 600; line-height: 1.1">Un sito che sai usare da solo</h3>
<p style="margin: 0; font-size: 18px; line-height: 1.55">Una bottega che ti lega a sé per ogni virgola non ti sta aiutando. Alla fine ricevi le chiavi e un libretto d’istruzioni.</p>
</div>
<div style="border-top: 2px solid var(--ink); padding-top: 18px">
<h3 class="h" style="margin: 0 0 10px; font-size: 26px; font-weight: 600; line-height: 1.1">Le parole contano quanto il codice</h3>
<p style="margin: 0; font-size: 18px; line-height: 1.55">Un sito che funziona ma non si capisce è una porta che si apre su una stanza vuota.</p>
</div>
<div style="border-top: 2px solid var(--ink); padding-top: 18px">
<h3 class="h" style="margin: 0 0 10px; font-size: 26px; font-weight: 600; line-height: 1.1">Piccola per scelta</h3>
<p style="margin: 0; font-size: 18px; line-height: 1.55">Pochi lavori alla volta, seguiti dall’inizio alla fine dalle stesse persone, quelle che ti hanno offerto il caffè.</p>
</div>
</div>
</section>

<section style="border-top: 1px solid var(--ink); padding: clamp(48px, 8vw, 96px) 0; text-align: center">
<h2 class="h" style="margin: 0 0 24px; font-size: clamp(34px, 4.6vw, 60px); line-height: 1; font-weight: 600">Il caffè lo offre<br>la bottega.</h2>
<a href="<?php echo esc_url( filo_url( 'contatti' ) ); ?>" class="btn fill m">Scrivi alla bottega</a>
</section>
<?php
get_footer();
