<?php
/**
 * Pagina «Insegna accesa».
 *
 * @package Filo
 */

get_header();
?>
<style>
.perchi-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:32px}
@media (max-width:1000px){.perchi-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:640px){.perchi-grid{grid-template-columns:minmax(0,1fr)}}
.hero-pol{flex:0 1 360px;max-width:400px;margin:0 0 0 auto;transform:rotate(-1.6deg)}
@media (max-width:760px){.hero-pol{flex-basis:100%;max-width:340px;margin:8px auto 0}}
</style>
<section style="padding: clamp(48px, 8vw, 104px) 0 clamp(40px, 6vw, 72px); display: flex; flex-wrap: wrap; align-items: center; gap: 40px 64px">
<div style="flex: 1 1 400px; min-width: 0">
<p class="m" style="margin: 0 0 24px; color: var(--mute)">La proposta della bottega</p>
<h1 class="h" style="margin: 0; font-size: clamp(44px, 6.4vw, 92px); line-height: .92; font-weight: 600; letter-spacing: -.045em">Insegna<br>accesa.</h1>
<p style="margin: 32px 0 0; max-width: 34em; font-size: clamp(19px, 1.7vw, 22px); line-height: 1.5">In una bottega l’insegna serve a dire a chi passa che sei aperto. Online è lo stesso: un sito scritto bene, la scheda Google in ordine e, se i tuoi clienti arrivano anche dall’estero, tutto anche in inglese. È la proposta di Filo, per farti trovare da chi ti sta già cercando.</p>
</div>
<figure class="hero-pol" style="background: var(--frame); padding: 12px 12px 0; box-shadow: 0 1px 2px rgba(0,0,0,.08), 0 10px 30px rgba(0,0,0,.09)">
<?php $filo_foto = get_posts( array( 'post_type' => 'attachment', 'name' => 'bottega-sera', 'posts_per_page' => 1 ) ); $filo_foto_src = $filo_foto ? wp_get_attachment_image_url( $filo_foto[0]->ID, 'large' ) : get_template_directory_uri() . '/assets/img/bottega-sera.jpg'; ?>
<img src="<?php echo esc_url( $filo_foto_src ); ?>" alt="La vetrina di una bottega al tramonto, con la luce calda accesa dentro e un filo vermiglio appeso a un chiodo sullo stipite" width="928" height="1152" style="display: block; width: 100%; height: auto; aspect-ratio: 4 / 5; object-fit: cover; background: var(--ph)">
<figcaption style="font-style: italic; font-size: 16px; color: #3A3732; padding: 14px 4px 18px">Dalla strada si vede se sei aperto.</figcaption>
</figure>
</section>

<section aria-labelledby="perchi" style="border-top: 1px solid var(--ink); padding: 48px 0 72px">
<h2 id="perchi" class="m" style="margin: 0 0 32px; color: var(--mute); font-weight: 400">Per chi</h2>
<div class="perchi-grid">
<div style="border-top: 2px solid var(--ink); padding-top: 18px">
<h3 class="h" style="margin: 0 0 8px; font-size: 22px; font-weight: 600; line-height: 1.1">Professionisti e studi</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Chi ti sceglie per nome, prima di chiamarti, ti cerca su Google.</p>
</div>
<div style="border-top: 2px solid var(--ink); padding-top: 18px">
<h3 class="h" style="margin: 0 0 8px; font-size: 22px; font-weight: 600; line-height: 1.1">Ospitalità e ristorazione</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Camere, tavole, cantine: per farsi trovare da chi arriva, da qualunque parte del mondo.</p>
</div>
<div style="border-top: 2px solid var(--ink); padding-top: 18px">
<h3 class="h" style="margin: 0 0 8px; font-size: 22px; font-weight: 600; line-height: 1.1">Botteghe, artigiani e negozi</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Per chi fa cose belle in un posto che Google non conosce ancora.</p>
</div>
<div style="border-top: 2px solid var(--ink); padding-top: 18px">
<h3 class="h" style="margin: 0 0 8px; font-size: 22px; font-weight: 600; line-height: 1.1">Corsi, guide ed esperienze</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Chi cerca qualcosa da fare lo cerca dal telefono, spesso il giorno prima.</p>
</div>
<div style="border-top: 2px solid var(--ink); padding-top: 18px">
<h3 class="h" style="margin: 0 0 8px; font-size: 22px; font-weight: 600; line-height: 1.1">Chi comincia adesso</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Un’attività nuova, un nome nuovo: meglio partire con l’insegna già accesa.</p>
</div>
</div>
</section>

<section aria-labelledby="comprende" style="border-top: 1px solid var(--ink); padding: 48px 0 24px">
<h2 id="comprende" class="m" style="margin: 0 0 8px; color: var(--mute); font-weight: 400">Cosa comprende</h2>

<article style="display: flex; flex-wrap: wrap; gap: 16px 48px; padding: 32px 0; border-bottom: 1px solid var(--line)">
<h3 class="h" style="flex: 1 1 280px; margin: 0; font-size: clamp(28px, 3vw, 38px); line-height: 1.05; font-weight: 600">Il sito, scritto bene</h3>
<div style="flex: 999 1 420px; min-width: 0">
<p style="margin: 0 0 12px; font-size: 19px; line-height: 1.55">Una vetrina curata, di poche pagine scritte bene: chi sei, cosa offri, dove sei, come prenotare o contattarti. Veloce sul telefono, con le tue foto vere e un tema disegnato su misura.</p>
<p style="margin: 0; font-size: 17px; line-height: 1.55; color: var(--mute)">Lo aggiorni da solo, quando vuoi, senza dover chiamare ogni volta.</p>
</div>
</article>

<article style="display: flex; flex-wrap: wrap; gap: 16px 48px; padding: 32px 0; border-bottom: 1px solid var(--line)">
<h3 class="h" style="flex: 1 1 280px; margin: 0; font-size: clamp(28px, 3vw, 38px); line-height: 1.05; font-weight: 600">La scheda Google, in ordine</h3>
<div style="flex: 999 1 420px; min-width: 0">
<p style="margin: 0 0 12px; font-size: 19px; line-height: 1.55">La scheda che compare su Google e su Maps quando qualcuno cerca un posto come il tuo: aperta o sistemata, con orari, categorie, descrizione, foto e il collegamento al sito.</p>
<p style="margin: 0; font-size: 17px; line-height: 1.55; color: var(--mute)">E un piccolo metodo per rispondere alle recensioni, anche a quelle storte.</p>
</div>
</article>

<article style="display: flex; flex-wrap: wrap; gap: 16px 48px; padding: 32px 0; border-bottom: 1px solid var(--line)">
<h3 class="h" style="flex: 1 1 280px; margin: 0; font-size: clamp(28px, 3vw, 38px); line-height: 1.05; font-weight: 600">Anche per le intelligenze artificiali</h3>
<div style="flex: 999 1 420px; min-width: 0">
<p style="margin: 0 0 12px; font-size: 19px; line-height: 1.55">Sempre più persone chiedono consiglio a un’intelligenza artificiale: «dove mangio a Favignana?», «una cantina da visitare vicino a Trapani?». Le risposte nascono da quello che trovano in rete. Sito e scheda vengono scritti perché si capisca bene chi sei, cosa fai e dove sei, con informazioni giuste e uguali ovunque, e con i dati che le macchine sanno leggere.</p>
<p style="margin: 0; font-size: 17px; line-height: 1.55; color: var(--mute)">Nessuna formula magica: un posto chiaro e ordinato piace alle persone, e per fortuna anche alle macchine.</p>
</div>
</article>

<article style="display: flex; flex-wrap: wrap; gap: 16px 48px; padding: 32px 0; border-bottom: 1px solid var(--line)">
<h3 class="h" style="flex: 1 1 280px; margin: 0; font-size: clamp(28px, 3vw, 38px); line-height: 1.05; font-weight: 600">In inglese</h3>
<div style="flex: 999 1 420px; min-width: 0">
<p style="margin: 0 0 12px; font-size: 19px; line-height: 1.55">Se i tuoi clienti arrivano anche dall’estero, sito e scheda anche in inglese. Testi scritti per chi legge in un’altra lingua, non tradotti a macchina.</p>
<p style="margin: 0; font-size: 17px; line-height: 1.55; color: var(--mute)">Per chi lavora solo con clienti italiani, si resta in italiano.</p>
</div>
</article>

<article style="display: flex; flex-wrap: wrap; gap: 16px 48px; padding: 32px 0; border-bottom: 1px solid var(--ink)">
<h3 class="h" style="flex: 1 1 280px; margin: 0; font-size: clamp(28px, 3vw, 38px); line-height: 1.05; font-weight: 600">La luce sempre accesa</h3>
<div style="flex: 999 1 420px; min-width: 0">
<p style="margin: 0 0 12px; font-size: 19px; line-height: 1.55">Con un piccolo canone la bottega tiene accesa l’insegna: aggiornamenti e copie di sicurezza del sito, orari e foto della scheda sempre giusti, piccole modifiche quando servono.</p>
<p style="margin: 0; font-size: 17px; line-height: 1.55; color: var(--mute)">E ogni tre mesi un resoconto semplice: quante persone ti hanno trovato e cosa hanno fatto, chiamato, chiesto la strada, visitato il sito.</p>
</div>
</article>
</section>

<section style="padding: 48px 0 72px">
<div style="background: var(--card); border: 1px solid var(--line); padding: clamp(24px, 4vw, 40px); max-width: 820px">
<p class="m" style="margin: 0 0 12px; color: var(--accent)">Una promessa onesta</p>
<p style="margin: 0; font-size: clamp(20px, 2vw, 24px); line-height: 1.45">Nessuno può garantirti il primo posto su Google o nelle risposte di un’intelligenza artificiale, e chi lo fa ti sta vendendo fumo. La bottega promette una cosa più semplice: che chi ti cerca trovi un posto curato, informazioni giuste e un buon motivo per sceglierti.</p>
</div>
</section>

<section style="border-top: 1px solid var(--line); padding: 72px 0">
<p class="m" style="margin: 0 0 36px; color: var(--mute); text-align: center">Come si lavora</p>
<ol style="list-style: none; margin: 0; padding: 0; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 32px">
<li style="border-top: 2px solid var(--ink); padding-top: 18px">
<p class="h" style="margin: 0 0 10px; font-size: 40px; font-weight: 600; color: var(--accent); line-height: 1">01</p>
<h3 class="h" style="margin: 0 0 8px; font-size: 21px; font-weight: 600">Un caffè</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Anche a distanza. Racconti cosa fai, e qui si ascolta più di quanto si parli. Non costa niente.</p>
</li>
<li style="border-top: 2px solid var(--ink); padding-top: 18px">
<p class="h" style="margin: 0 0 10px; font-size: 40px; font-weight: 600; color: var(--accent); line-height: 1">02</p>
<h3 class="h" style="margin: 0 0 8px; font-size: 21px; font-weight: 600">Il progetto su carta</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Pagine, parole, tempi e preventivo, messi per iscritto prima di toccare il codice.</p>
</li>
<li style="border-top: 2px solid var(--ink); padding-top: 18px">
<p class="h" style="margin: 0 0 10px; font-size: 40px; font-weight: 600; color: var(--accent); line-height: 1">03</p>
<h3 class="h" style="margin: 0 0 8px; font-size: 21px; font-weight: 600">La costruzione</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Vedi il sito crescere su un indirizzo di prova, lo correggiamo insieme, poi si accende anche su Google.</p>
</li>
<li style="border-top: 2px solid var(--ink); padding-top: 18px">
<p class="h" style="margin: 0 0 10px; font-size: 40px; font-weight: 600; color: var(--accent); line-height: 1">04</p>
<h3 class="h" style="margin: 0 0 8px; font-size: 21px; font-weight: 600">Le chiavi</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Ricevi sito, accessi e un libretto d’istruzioni scritto per esseri umani. Se vuoi, la bottega tiene accesa la luce.</p>
</li>
</ol>
</section>

<section style="padding-bottom: 72px">
<div style="background: var(--card); border: 1px solid var(--line); padding: 28px; max-width: 820px">
<h2 class="h" style="margin: 0 0 14px; font-size: 24px; font-weight: 600">Come nasce il preventivo</h2>
<p style="margin: 0; font-size: 17px; line-height: 1.55">Ogni insegna ha il suo, scritto dopo il caffè: dipende dalle pagine, dalle foto e dai testi da fare da zero, dalla versione in inglese e da quanto c’è da sistemare nella scheda. Il caffè e il preventivo non costano niente.</p>
</div>
</section>

<section style="border-top: 1px solid var(--ink); padding: clamp(48px, 8vw, 96px) 0; text-align: center">
<h2 class="h" style="margin: 0 0 24px; font-size: clamp(34px, 4.6vw, 60px); line-height: 1; font-weight: 600">Accendiamo<br>la tua insegna?</h2>
<a href="<?php echo esc_url( filo_url( 'contatti' ) ); ?>" class="btn fill m">Scrivi alla bottega</a>
</section>
<?php
get_footer();
