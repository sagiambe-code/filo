<?php
/**
 * Il modulo «Scrivi alla bottega»: in home e nella pagina Contatti.
 *
 * Spedisce una mail con wp_mail() all'indirizzo scelto in Personalizza → Filo
 * (o, se vuoto, all'email di amministrazione). Niente plugin, niente database:
 * il messaggio arriva solo nella casella.
 *
 * @package Filo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Campi nascosti del modulo: azione, sicurezza, provenienza, trappola per i robot.
 */
function filo_form_fields( $origine ) {
	echo '<input type="hidden" name="action" value="filo_contatto">';
	echo '<input type="hidden" name="origine" value="' . esc_attr( $origine ) . '">';
	echo '<input type="hidden" name="attivita" value="" data-topic-field>';
	echo '<input type="hidden" name="t" value="' . esc_attr( time() ) . '">';
	wp_nonce_field( 'filo_contatto', 'filo_nonce' );
	// Chi compila questo campo invisibile non è una persona.
	echo '<p style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden" aria-hidden="true"><label>Lascia vuoto<input type="text" name="sito_web" tabindex="-1" autocomplete="off"></label></p>';
}

/**
 * Esito dell'invio, letto dall'indirizzo dopo il rimando.
 */
function filo_form_status() {
	if ( isset( $_GET['inviato'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return 'ok';
	}
	if ( isset( $_GET['errore'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return sanitize_key( wp_unslash( $_GET['errore'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}
	return '';
}

/**
 * Messaggio sopra il modulo. In home mostra anche il grazie;
 * nella pagina Contatti il grazie ha il suo riquadro.
 */
function filo_form_notice( $origine ) {
	$status = filo_form_status();
	if ( ! $status ) {
		return;
	}
	$style = 'margin: 0; padding: 14px 16px; font-size: 17px; line-height: 1.45; border-left: 2px solid #D9432B; background: rgba(217,67,43,.07); color: #151411';
	if ( 'ok' === $status ) {
		if ( 'home' === $origine ) {
			echo '<p role="status" style="' . esc_attr( $style ) . '"><strong>Ricevuto.</strong> Le tue due righe sono sul banco: ti risponde la bottega, di solito entro un giorno.</p>';
		}
		return;
	}
	$messages = array(
		'campi'   => 'Mancano il nome, l’email o qualche parola sul messaggio.',
		'email'   => 'L’indirizzo email non sembra giusto: ricontrollalo.',
		'privacy' => 'Per rispondere serve il tuo consenso all’informativa privacy.',
		'invio'   => 'Il messaggio non è partito, ma non è colpa tua. Prova ancora o scrivi direttamente a ' . filo_opt( 'email' ) . '.',
	);
	$text = isset( $messages[ $status ] ) ? $messages[ $status ] : 'Qualcosa non è andato. Riprova tra poco.';
	echo '<p role="alert" style="' . esc_attr( $style ) . '">' . esc_html( $text ) . '</p>';
}

/**
 * Riceve il modulo.
 */
function filo_handle_contatto() {
	$origine = isset( $_POST['origine'] ) && 'home' === $_POST['origine'] ? 'home' : 'contatti';
	$back    = 'home' === $origine ? home_url( '/' ) : filo_url( 'contatti' );
	$anchor  = 'home' === $origine ? '#scrivimi' : '#modulo';

	$go = function ( $args ) use ( $back, $anchor ) {
		wp_safe_redirect( add_query_arg( $args, $back ) . $anchor );
		exit;
	};

	if ( ! isset( $_POST['filo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['filo_nonce'] ) ), 'filo_contatto' ) ) {
		$go( array( 'errore' => 'scaduto' ) );
	}

	// Robot: campo trappola compilato, o modulo inviato in meno di tre secondi.
	$t = isset( $_POST['t'] ) ? (int) $_POST['t'] : 0;
	if ( ! empty( $_POST['sito_web'] ) || ( $t && time() - $t < 3 ) ) {
		$go( array( 'inviato' => 1 ) );
	}

	$nome      = isset( $_POST['nome'] ) ? sanitize_text_field( wp_unslash( $_POST['nome'] ) ) : '';
	$email     = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$messaggio = isset( $_POST['messaggio'] ) ? sanitize_textarea_field( wp_unslash( $_POST['messaggio'] ) ) : '';
	$attivita  = isset( $_POST['attivita'] ) ? sanitize_text_field( wp_unslash( $_POST['attivita'] ) ) : '';
	$privacy   = ! empty( $_POST['privacy'] );

	if ( '' === $nome || '' === $messaggio || '' === trim( (string) wp_unslash( $_POST['email'] ?? '' ) ) ) {
		$go( array( 'errore' => 'campi' ) );
	}
	if ( ! is_email( $email ) ) {
		$go( array( 'errore' => 'email' ) );
	}
	if ( ! $privacy ) {
		$go( array( 'errore' => 'privacy' ) );
	}

	$to = filo_opt( 'destinatario' );
	if ( ! is_email( $to ) ) {
		$to = get_option( 'admin_email' );
	}

	$subject = 'Filo · Due righe da ' . $nome . ( $attivita ? ' (' . $attivita . ')' : '' );
	$body    = "Nome: $nome\nEmail: $email\n" . ( $attivita ? "Attività: $attivita\n" : '' ) . 'Dal modulo: ' . ( 'home' === $origine ? 'home' : 'pagina Contatti' ) . "\n\n$messaggio\n";
	$headers = array( 'Reply-To: ' . $nome . ' <' . $email . '>' );

	$sent = wp_mail( $to, $subject, $body, $headers );
	$go( $sent ? array( 'inviato' => 1 ) : array( 'errore' => 'invio' ) );
}
add_action( 'admin_post_nopriv_filo_contatto', 'filo_handle_contatto' );
add_action( 'admin_post_filo_contatto', 'filo_handle_contatto' );

/**
 * Le mail partono da un indirizzo del sito, non da «wordpress@».
 */
add_filter( 'wp_mail_from_name', function ( $name ) {
	return 'WordPress' === $name ? 'Filo · Bottega creativa' : $name;
} );
