<?php
/**
 * Quando il tema viene attivato prepara il sito:
 * crea le pagine che mancano, la categoria delle guide e la bozza
 * dell'informativa privacy. Non tocca nulla che esista già.
 *
 * @package Filo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function filo_attivazione() {
	$pagine = array(
		'insegna-accesa' => 'Insegna accesa',
		'bottega-aperta' => 'Bottega aperta',
		'chi-ce-dietro'  => 'Chi c’è dietro',
		'contatti'       => 'Contatti',
	);
	foreach ( $pagine as $slug => $titolo ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => $titolo,
					'post_name'    => $slug,
					'post_content' => '<!-- wp:paragraph --><p>I testi di questa pagina sono nel tema Filo.</p><!-- /wp:paragraph -->',
				)
			);
		}
	}

	// La categoria delle guide di Bottega aperta.
	if ( ! term_exists( 'attrezzi', 'category' ) ) {
		wp_insert_term( 'Attrezzi', 'category', array( 'slug' => 'attrezzi', 'description' => 'Le guide di Bottega aperta.' ) );
	}

	// L'informativa privacy: resta in bozza finché non è completata e verificata.
	$privacy_id = (int) get_option( 'wp_page_for_privacy_policy' );
	$privacy    = $privacy_id ? get_post( $privacy_id ) : null;
	$testo      = file_get_contents( get_template_directory() . '/inc/privacy-bozza.html' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( $privacy && 'draft' === $privacy->post_status && false === strpos( $privacy->post_content, '<!-- filo -->' ) ) {
		wp_update_post(
			array(
				'ID'           => $privacy_id,
				'post_title'   => 'Privacy e cookie',
				'post_name'    => 'privacy',
				'post_content' => $testo,
			)
		);
	} elseif ( ! $privacy ) {
		$new_id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'draft',
				'post_title'   => 'Privacy e cookie',
				'post_name'    => 'privacy',
				'post_content' => $testo,
			)
		);
		if ( $new_id && ! is_wp_error( $new_id ) ) {
			update_option( 'wp_page_for_privacy_policy', $new_id );
		}
	}

	filo_register_racconti();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'filo_attivazione' );
