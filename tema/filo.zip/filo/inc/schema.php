<?php
/**
 * Dati strutturati per Google e per le intelligenze artificiali:
 * chi è la bottega, cosa fa, come contattarla.
 *
 * @package Filo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_head', function () {
	if ( ! is_front_page() && ! is_page( array( 'chi-ce-dietro', 'contatti', 'insegna-accesa' ) ) ) {
		return;
	}

	$same_as = array();
	if ( filo_opt( 'instagram' ) ) {
		$same_as[] = filo_opt( 'instagram' );
	}

	$data = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'ProfessionalService',
		'@id'         => home_url( '/#bottega' ),
		'name'        => 'Filo · Bottega creativa',
		'alternateName' => 'Filo',
		'description' => filo_opt( 'descrizione' ),
		'url'         => home_url( '/' ),
		'email'       => filo_opt( 'email' ),
		'telephone'   => preg_replace( '/\s+/', '', (string) filo_opt( 'telefono' ) ),
		'image'       => get_template_directory_uri() . '/screenshot.png',
		'logo'        => get_template_directory_uri() . '/assets/favicon.svg',
		'areaServed'  => array( 'Sicilia', 'Italia' ),
		'address'     => array(
			'@type'           => 'PostalAddress',
			'addressRegion'   => filo_opt( 'luogo' ),
			'addressCountry'  => 'IT',
		),
		'founder'     => array(
			'@type'    => 'Person',
			'name'     => 'Salvatore Giambelluca',
			'jobTitle' => 'Web designer',
			'url'      => filo_url( 'chi-ce-dietro' ),
		),
		'knowsLanguage' => array( 'it', 'en' ),
		'makesOffer'  => array(
			'@type'       => 'Offer',
			'itemOffered' => array(
				'@type'       => 'Service',
				'name'        => 'Insegna accesa',
				'description' => 'Sito scritto bene, scheda Google in ordine, inglese per chi arriva da fuori, cura continuativa.',
				'url'         => filo_url( 'insegna-accesa' ),
			),
		),
	);
	if ( $same_as ) {
		$data['sameAs'] = $same_as;
	}

	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
} );
