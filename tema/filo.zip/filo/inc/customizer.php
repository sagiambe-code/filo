<?php
/**
 * Aspetto → Personalizza → Filo: contatti e piccole impostazioni.
 *
 * @package Filo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'customize_register', function ( $wp_customize ) {
	$d = filo_defaults();

	$wp_customize->add_section(
		'filo',
		array(
			'title'       => 'Filo',
			'priority'    => 30,
			'description' => 'Contatti e dettagli della bottega. Compaiono in tutte le pagine.',
		)
	);

	$fields = array(
		'email'        => array( 'Email della bottega (quella che si vede nel sito)', 'email', 'sanitize_email' ),
		'destinatario' => array( 'Email che riceve i messaggi del modulo (se vuota: l’email di amministrazione)', 'email', 'sanitize_email' ),
		'telefono'     => array( 'Numero da mostrare', 'text', 'sanitize_text_field' ),
		'whatsapp'     => array( 'Numero WhatsApp, solo cifre con prefisso (es. 393801707593)', 'text', 'sanitize_text_field' ),
		'wa_testo'     => array( 'Messaggio già scritto su WhatsApp', 'text', 'sanitize_text_field' ),
		'social'       => array( 'Nome sui social (es. @filobottega)', 'text', 'sanitize_text_field' ),
		'instagram'    => array( 'Indirizzo del profilo Instagram (facoltativo)', 'url', 'esc_url_raw' ),
		'luogo'        => array( 'Dove sta la bottega', 'text', 'sanitize_text_field' ),
		'descrizione'  => array( 'Descrizione della home per Google', 'textarea', 'sanitize_textarea_field' ),
	);

	foreach ( $fields as $key => $f ) {
		$wp_customize->add_setting(
			'filo_' . $key,
			array(
				'default'           => $d[ $key ],
				'sanitize_callback' => $f[2],
			)
		);
		$wp_customize->add_control(
			'filo_' . $key,
			array(
				'label'   => $f[0],
				'section' => 'filo',
				'type'    => $f[1],
			)
		);
	}

	$wp_customize->add_setting(
		'filo_aperta',
		array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
		)
	);
	$wp_customize->add_control(
		'filo_aperta',
		array(
			'label'   => 'Mostra «● Bottega aperta» in cima alla home',
			'section' => 'filo',
			'type'    => 'checkbox',
		)
	);
} );
