<?php
/**
 * Aggiornamenti del tema senza caricare file a mano.
 *
 * Il tema controlla un piccolo file su GitHub (version.json). Se lì c'è una
 * versione più nuova, WordPress la mostra tra gli aggiornamenti, come per i
 * temi ufficiali, e con gli aggiornamenti automatici attivi la installa da solo.
 *
 * @package Filo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'FILO_UPDATE_URL', 'https://raw.githubusercontent.com/sagiambe-code/filo/main/tema/version.json' );

/**
 * Legge il file della versione, tenendolo da parte per un'ora.
 */
function filo_remote_version( $force = false ) {
	$cached = get_transient( 'filo_remote_version' );
	if ( ! $force && is_array( $cached ) ) {
		return $cached;
	}
	$response = wp_remote_get( FILO_UPDATE_URL . '?t=' . time(), array( 'timeout' => 8 ) );
	if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
		return null;
	}
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( empty( $data['version'] ) || empty( $data['package'] ) ) {
		return null;
	}
	set_transient( 'filo_remote_version', $data, HOUR_IN_SECONDS );
	return $data;
}

add_filter( 'pre_set_site_transient_update_themes', function ( $transient ) {
	if ( ! is_object( $transient ) ) {
		$transient = new stdClass();
	}
	$slug    = get_template();
	$current = wp_get_theme( $slug )->get( 'Version' );
	$remote  = filo_remote_version( ! empty( $_GET['force-check'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! $remote ) {
		return $transient;
	}
	$item = array(
		'theme'        => $slug,
		'new_version'  => $remote['version'],
		'url'          => 'https://www.filobottega.it/',
		'package'      => $remote['package'],
		'requires'     => '6.4',
		'requires_php' => '8.0',
	);
	if ( version_compare( $remote['version'], $current, '>' ) ) {
		$transient->response[ $slug ] = $item;
		unset( $transient->no_update[ $slug ] );
	} else {
		// Serve a WordPress per mostrare l'interruttore «aggiornamenti automatici».
		$transient->no_update[ $slug ] = $item;
	}
	return $transient;
} );
