<?php
/**
 * I racconti: i lavori della bottega, raccontati.
 *
 * Ogni racconto è un contenuto a sé (bacheca → Racconti), con l'indirizzo
 * filobottega.it/lavori/nome-del-racconto/. Finché non ce n'è almeno uno
 * pubblicato, la voce Lavori e la sezione in home non compaiono.
 *
 * @package Filo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function filo_register_racconti() {
	register_post_type(
		'racconto',
		array(
			'labels'       => array(
				'name'               => 'Racconti',
				'singular_name'      => 'Racconto',
				'add_new'            => 'Aggiungi racconto',
				'add_new_item'       => 'Nuovo racconto',
				'edit_item'          => 'Modifica racconto',
				'new_item'           => 'Nuovo racconto',
				'view_item'          => 'Leggi il racconto',
				'search_items'       => 'Cerca tra i racconti',
				'not_found'          => 'Nessun racconto, per ora.',
				'not_found_in_trash' => 'Nessun racconto nel cestino.',
				'all_items'          => 'Tutti i racconti',
				'menu_name'          => 'Racconti',
			),
			'public'       => true,
			'has_archive'  => 'lavori',
			'rewrite'      => array( 'slug' => 'lavori', 'with_front' => false ),
			'menu_icon'    => 'dashicons-format-quote',
			'menu_position'=> 5,
			'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions' ),
			'show_in_rest' => true,
		)
	);

	foreach ( array( 'cliente', 'lavoro', 'sito', 'didascalia' ) as $key ) {
		register_post_meta(
			'racconto',
			'filo_' . $key,
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sito' === $key ? 'esc_url_raw' : 'sanitize_text_field',
				'auth_callback'     => function () {
					return current_user_can( 'edit_posts' );
				},
			)
		);
	}
}
add_action( 'init', 'filo_register_racconti' );

/**
 * Il riquadro «Dettagli del racconto» nella schermata di modifica.
 */
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'filo_racconto', 'Dettagli del racconto', 'filo_racconto_box', 'racconto', 'side', 'high' );
} );

function filo_racconto_fields() {
	return array(
		'cliente'    => array( 'Cliente', 'Es. Cantina Rossi' ),
		'lavoro'     => array( 'Cosa ha fatto la bottega', 'Es. Tema WordPress su misura' ),
		'sito'       => array( 'Indirizzo del sito', 'https://' ),
		'didascalia' => array( 'Didascalia della foto', 'Es. La home, prima delle parole.' ),
	);
}

function filo_racconto_box( $post ) {
	wp_nonce_field( 'filo_racconto', 'filo_racconto_nonce' );
	foreach ( filo_racconto_fields() as $key => $f ) {
		$value = get_post_meta( $post->ID, 'filo_' . $key, true );
		printf(
			'<p><label for="filo_%1$s" style="display:block;font-weight:600;margin-bottom:4px">%2$s</label><input type="%5$s" id="filo_%1$s" name="filo_%1$s" value="%3$s" placeholder="%4$s" style="width:100%%"></p>',
			esc_attr( $key ),
			esc_html( $f[0] ),
			esc_attr( $value ),
			esc_attr( $f[1] ),
			'sito' === $key ? 'url' : 'text'
		);
	}
	echo '<p style="color:#646970">La foto in evidenza diventa la polaroid in cima al racconto. L’estratto è la riga che compare nell’elenco.</p>';
}

add_action( 'save_post_racconto', function ( $post_id ) {
	if ( ! isset( $_POST['filo_racconto_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['filo_racconto_nonce'] ) ), 'filo_racconto' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( array_keys( filo_racconto_fields() ) as $key ) {
		if ( isset( $_POST[ 'filo_' . $key ] ) ) {
			$raw   = wp_unslash( $_POST[ 'filo_' . $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$value = 'sito' === $key ? esc_url_raw( $raw ) : sanitize_text_field( $raw );
			update_post_meta( $post_id, 'filo_' . $key, $value );
		}
	}
} );

/**
 * Un racconto nuovo parte già con la traccia della bottega.
 */
add_filter( 'default_content', function ( $content, $post ) {
	if ( 'racconto' !== $post->post_type ) {
		return $content;
	}
	return filo_racconto_traccia();
}, 10, 2 );

function filo_racconto_traccia() {
	$h = function ( $t ) {
		return "<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\">$t</h3>\n<!-- /wp:heading -->\n\n";
	};
	$p = function ( $t ) {
		return "<!-- wp:paragraph -->\n<p>$t</p>\n<!-- /wp:paragraph -->\n\n";
	};
	return $h( 'Il prima' ) . $p( 'Chi è, cosa fa e che sito voleva. Com’era la situazione all’inizio.' )
		. $h( 'Il problema' ) . $p( 'Cosa non funzionava.' )
		. "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><!-- wp:paragraph -->\n<p>Una frase del cliente, se vorrà prestarcela.</p>\n<!-- /wp:paragraph --></blockquote>\n<!-- /wp:quote -->\n\n"
		. $h( 'Cosa abbiamo tolto' ) . $p( 'Le pagine e le cose eliminate, e perché.' )
		. $h( 'Cosa è rimasto' ) . $p( 'Il tema su misura, i colori, i testi riscritti insieme.' )
		. $h( 'L’errore utile' ) . $p( 'Una cosa che non ha funzionato al primo tentativo, e cosa ha insegnato.' );
}

/**
 * Nell'elenco dei Lavori, i racconti più recenti per primi, tutti in una pagina.
 */
add_action( 'pre_get_posts', function ( $q ) {
	if ( ! is_admin() && $q->is_main_query() && $q->is_post_type_archive( 'racconto' ) ) {
		$q->set( 'posts_per_page', 50 );
	}
} );
