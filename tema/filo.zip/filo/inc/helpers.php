<?php
/**
 * Piccoli aiuti usati dai template.
 *
 * @package Filo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Valori predefiniti delle impostazioni (modificabili da Aspetto → Personalizza → Filo).
 */
function filo_defaults() {
	return array(
		'email'       => 'ciao@filobottega.it',
		'telefono'    => '+39 380 170 7593',
		'whatsapp'    => '393801707593',
		'wa_testo'    => 'Ciao Filo, vorrei accendere la mia insegna',
		'social'      => '@filobottega',
		'instagram'   => '',
		'luogo'       => 'Sicilia',
		'aperta'      => true,
		'destinatario'=> '',
		'descrizione' => 'Filo è una piccola bottega creativa siciliana: costruisce siti per professionisti e non solo, ne scrive i testi e li accende dove la gente cerca davvero.',
	);
}

/**
 * Legge un'impostazione del tema.
 */
function filo_opt( $key ) {
	$defaults = filo_defaults();
	$value    = get_theme_mod( 'filo_' . $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	return $value;
}

/**
 * Link a WhatsApp con il messaggio già scritto.
 */
function filo_wa_url() {
	$num = preg_replace( '/\D+/', '', (string) filo_opt( 'whatsapp' ) );
	return 'https://wa.me/' . $num . '?text=' . rawurlencode( filo_opt( 'wa_testo' ) );
}

/**
 * Indirizzo di una pagina del sito, cercata per slug.
 */
function filo_url( $slug ) {
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
}

/**
 * Indirizzo dell'informativa privacy.
 */
function filo_privacy_url() {
	$url = get_privacy_policy_url();
	return $url ? $url : filo_url( 'privacy' );
}

/**
 * Ci sono racconti pubblicati? Finché no, la voce Lavori resta nascosta.
 */
function filo_has_racconti() {
	$count = wp_count_posts( 'racconto' );
	return isset( $count->publish ) && (int) $count->publish > 0;
}

/**
 * Le voci del menu, con quella corrente in rosso.
 */
function filo_pages() {
	$items = array( array( 'Insegna accesa', filo_url( 'insegna-accesa' ), is_page( 'insegna-accesa' ) ) );
	if ( filo_has_racconti() ) {
		$items[] = array( 'Lavori', get_post_type_archive_link( 'racconto' ), is_post_type_archive( 'racconto' ) || is_singular( 'racconto' ) );
	}
	$items[] = array( 'Bottega aperta', filo_url( 'bottega-aperta' ), is_page( 'bottega-aperta' ) || ( is_singular( 'post' ) && in_category( 'attrezzi' ) ) );
	$items[] = array( 'Chi c’è dietro', filo_url( 'chi-ce-dietro' ), is_page( 'chi-ce-dietro' ) );
	$items[] = array( 'Contatti', filo_url( 'contatti' ), is_page( 'contatti' ) );
	return $items;
}

function filo_nav_links() {
	foreach ( filo_pages() as $item ) {
		list( $label, $url, $current ) = $item;
		printf(
			'<a href="%s" class="m%s"%s>%s</a>' . "\n",
			esc_url( $url ),
			$current ? ' here' : '',
			$current ? ' aria-current="page"' : '',
			esc_html( $label )
		);
	}
}

function filo_footer_links() {
	foreach ( filo_pages() as $item ) {
		printf( '<li><a href="%s" style="display: inline-block; padding: 5px 0">%s</a></li>' . "\n", esc_url( $item[1] ), esc_html( $item[0] ) );
	}
}

/**
 * Il marchio: «F» + lampadina + «lo».
 */
function filo_logo( $size = 44, $label = 'Filo, torna alla home', $href = '' ) {
	$href = $href ? $href : home_url( '/' );
	printf(
		'<a href="%1$s" class="h" aria-label="%2$s" style="font-size: %3$dpx; font-weight: 700; letter-spacing: -.055em; line-height: 1">F<svg class="logo-bulb" viewBox="0 0 24 74" aria-hidden="true"><path class="glass" d="M12 0 C 20 0 24 7 24 15 C 24 23 19 28 17.5 33 L 17.5 38 L 6.5 38 L 6.5 33 C 5 28 0 23 0 15 C 0 7 4 0 12 0 Z" fill="var(--accent)"></path><rect x="6.5" y="39.5" width="11" height="34.5" fill="currentColor"></rect></svg><span style="letter-spacing: -.005em">l</span>o</a>',
		esc_url( $href ),
		esc_attr( $label ),
		(int) $size
	);
}

/**
 * Le guide della bottega: articoli nella categoria «Attrezzi».
 */
function filo_guide_query( $n = 6 ) {
	return new WP_Query(
		array(
			'post_type'           => 'post',
			'category_name'       => 'attrezzi',
			'posts_per_page'      => $n,
			'ignore_sticky_posts' => true,
		)
	);
}

/**
 * Una data scritta per bene: «22 novembre 2026».
 */
function filo_date( $post = null ) {
	return date_i18n( 'j F Y', get_post_time( 'U', false, $post ) );
}

/**
 * Il nome sui social, con il link a Instagram se c'è.
 */
function filo_social() {
	$name = filo_opt( 'social' );
	$url  = filo_opt( 'instagram' );
	if ( $url ) {
		printf( '<a href="%s" rel="me" style="border-bottom: 1px solid var(--accent)">%s</a>', esc_url( $url ), esc_html( $name ) );
	} else {
		echo esc_html( $name );
	}
}
