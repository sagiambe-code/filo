<?php
/**
 * Piè di pagina.
 *
 * @package Filo
 */
?>
</main>

<footer style="border-top: 1px solid var(--ink); padding: 48px 0 32px">
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 32px 40px; padding-bottom: 40px">
<div>
<?php filo_logo( 40 ); ?>
<p class="m" style="margin: 10px 0 0; letter-spacing: .2em">Bottega creativa</p>
<p style="margin: 16px 0 0; max-width: 18em; font-size: 16px; line-height: 1.5; color: var(--mute)">Siti che funzionano, raccontati. Dalla Sicilia, fin dove arriva il filo.</p>
</div>
<nav aria-label="Pagine del sito">
<p class="m" style="margin: 0 0 8px; color: var(--mute)">Pagine</p>
<ul style="list-style: none; margin: 0; padding: 0; font-size: 17px; line-height: 1.4">
<?php filo_footer_links(); ?>
</ul>
</nav>
<div>
<p class="m" style="margin: 0 0 8px; color: var(--mute)">Scrivi alla bottega</p>
<p style="margin: 0; font-size: 17px; line-height: 1.9"><a href="<?php echo esc_url( 'mailto:' . filo_opt( 'email' ) ); ?>" style="border-bottom: 1px solid var(--accent)"><?php echo esc_html( filo_opt( 'email' ) ); ?></a><br><a href="<?php echo esc_url( filo_wa_url() ); ?>" style="border-bottom: 1px solid var(--accent)">WhatsApp · <?php echo esc_html( filo_opt( 'telefono' ) ); ?></a><br><?php echo esc_html( filo_opt( 'luogo' ) ); ?><br><?php filo_social(); ?></p>
</div>
</div>
<div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 12px 24px; padding-top: 20px; border-top: 1px solid var(--line)">
<span class="m" style="color: var(--mute)">© <?php echo esc_html( wp_date( 'Y' ) ); ?> Filo · Salvatore Giambelluca</span>
<span class="m" style="color: var(--mute)"><a href="<?php echo esc_url( filo_privacy_url() ); ?>" style="color: var(--mute); border-bottom: 1px solid currentColor">Privacy e cookie</a> · Sito costruito da Filo</span>
</div>
</footer>

</div>
</div>
<?php wp_footer(); ?>
</body>
</html>
