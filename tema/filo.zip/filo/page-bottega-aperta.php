<?php
/**
 * Pagina «Bottega aperta»: il test «Ti trovano?» e le guide.
 *
 * @package Filo
 */

get_header();
?>
<section style="padding: clamp(48px, 8vw, 104px) 0 clamp(40px, 6vw, 72px)">
<p class="m" style="margin: 0 0 24px; color: var(--mute)">Bottega aperta</p>
<h1 class="h" style="margin: 0; font-size: clamp(44px, 6.4vw, 92px); line-height: .92; font-weight: 600; letter-spacing: -.045em">Sul banco,<br>per chi passa.</h1>
<p style="margin: 32px 0 0; max-width: 34em; font-size: clamp(19px, 1.7vw, 22px); line-height: 1.5">Attrezzi che la bottega usa ogni giorno, lasciati qui per chi ha un’attività da far trovare. Prendi quello che ti serve: non chiediamo la mail in cambio.</p>
</section>

<section id="lista" style="border-top: 1px solid var(--ink); padding: 48px 0 72px; display: flex; flex-wrap: wrap; gap: 32px 64px">
<div style="flex: 1 1 280px; min-width: 0">
<p class="m" style="margin: 0 0 14px; color: var(--accent)">Strumento</p>
<h2 class="h" style="margin: 0 0 16px; font-size: clamp(30px, 3.4vw, 44px); line-height: 1; font-weight: 600">Ti trovano?</h2>
<p style="margin: 0 0 24px; font-size: 18px; line-height: 1.5">Undici domande da farti col telefono in mano. Cinque minuti, e sai quali lampadine della tua insegna sono accese e quali no.</p>
<p class="h" style="margin: 0 0 6px; font-size: 22px; font-weight: 600" aria-live="polite" data-progress>Da cominciare</p>
<button type="button" class="reset m" data-reset>Ricomincia</button>
</div>
<div style="flex: 999 1 520px; min-width: 0; display: flex; flex-direction: column; gap: 32px">
<fieldset style="border: 0; margin: 0; padding: 0">
<legend class="m" style="padding: 0 0 6px; color: var(--mute)">Su Google</legend>
<label class="chk"><input type="checkbox" data-check="a0"><span>Cerchi il nome della tua attività e compare la scheda giusta, con gli orari aggiornati</span></label>
<label class="chk"><input type="checkbox" data-check="a1"><span>Ci sono foto recenti, fatte con la luce buona</span></label>
<label class="chk"><input type="checkbox" data-check="a2"><span>Rispondi alle recensioni, anche a quelle storte</span></label>
<label class="chk"><input type="checkbox" data-check="a3"><span>Il telefono della scheda squilla davvero</span></label>
</fieldset>
<fieldset style="border: 0; margin: 0; padding: 0">
<legend class="m" style="padding: 0 0 6px; color: var(--mute)">Sul sito</legend>
<label class="chk"><input type="checkbox" data-check="b0"><span>Si apre bene dal telefono</span></label>
<label class="chk"><input type="checkbox" data-check="b1"><span>In tre secondi si capisce cosa fai e dove sei</span></label>
<label class="chk"><input type="checkbox" data-check="b2"><span>C’è un modo immediato per chiamarti o scriverti</span></label>
<label class="chk"><input type="checkbox" data-check="b3"><span>C’è almeno una pagina in inglese</span></label>
</fieldset>
<fieldset style="border: 0; margin: 0; padding: 0">
<legend class="m" style="padding: 0 0 6px; color: var(--mute)">Tutto il resto</legend>
<label class="chk"><input type="checkbox" data-check="c0"><span>Chi cerca quello che fai, dove lo fai, ti trova tra i primi risultati</span></label>
<label class="chk"><input type="checkbox" data-check="c1"><span>Social e sito dicono le stesse cose, con gli stessi orari</span></label>
<label class="chk"><input type="checkbox" data-check="c2"><span>Se chiedi a un’intelligenza artificiale di consigliarti un posto come il tuo, ti nomina</span></label>
</fieldset>
</div>
</section>

<?php get_template_part( 'template-parts/guide' ); ?>

<section style="border-top: 1px solid var(--line); padding: clamp(48px, 8vw, 88px) 0; text-align: center">
<p style="margin: 0 auto 24px; max-width: 26em; font-size: 22px; line-height: 1.45; font-style: italic">Qualche lampadina è rimasta spenta? La bottega può accendere la tua insegna.</p>
<a href="<?php echo esc_url( filo_url( 'insegna-accesa' ) ); ?>" class="m" style="border-bottom: 1px solid var(--accent); padding-bottom: 2px">Insegna accesa</a>
</section>
<?php
get_footer();
