<?php
/**
 * Un articolo: di solito una guida di Bottega aperta.
 *
 * @package Filo
 */

get_header();
while ( have_posts() ) :
	the_post();
	$filo_guida = in_category( 'attrezzi' );
	?>
<article style="padding: clamp(48px, 8vw, 104px) 0 0">
<header style="max-width: 760px; margin: 0 0 clamp(40px, 6vw, 64px)">
<p class="m" style="margin: 0 0 24px; color: var(--mute)">
<?php if ( $filo_guida ) : ?>
<a href="<?php echo esc_url( filo_url( 'bottega-aperta' ) ); ?>" style="color: var(--mute)">Bottega aperta</a> · <span style="color: var(--accent)">Guida</span>
<?php else : ?>
<?php echo esc_html( filo_date() ); ?>
<?php endif; ?>
</p>
<h1 class="h" style="margin: 0; font-size: clamp(40px, 5.6vw, 80px); line-height: .95; font-weight: 600; letter-spacing: -.04em"><?php the_title(); ?></h1>
<?php if ( has_excerpt() ) : ?><p style="margin: 28px 0 0; max-width: 34em; font-size: clamp(19px, 1.7vw, 22px); line-height: 1.5"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
<?php if ( $filo_guida ) : ?><p class="m" style="margin: 20px 0 0; color: var(--mute)">Aggiornata il <?php echo esc_html( date_i18n( 'j F Y', get_the_modified_time( 'U' ) ) ); ?></p><?php endif; ?>
</header>

<div style="border-top: 1px solid var(--ink); padding: 48px 0 0">
<div class="prose" style="max-width: 680px">
<?php the_content(); ?>
</div>
</div>

<div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 16px; margin-top: 56px; padding: 24px 0 72px; border-top: 1px solid var(--line)">
<a href="<?php echo esc_url( filo_url( 'bottega-aperta' ) ); ?>" class="m" style="border-bottom: 1px solid currentColor; padding-bottom: 2px">Torna al banco</a>
<a href="<?php echo esc_url( filo_url( 'insegna-accesa' ) ); ?>" class="m" style="color: var(--accent)">Preferisci che ci pensi la bottega? Insegna accesa</a>
</div>
</article>
	<?php
endwhile;
get_footer();
