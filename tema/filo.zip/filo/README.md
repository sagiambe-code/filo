# Filo · il tema

Il tema su misura di **Filo – Bottega creativa** (filobottega.it). È un tema WordPress classico, scritto a mano a partire dal prototipo: niente costruttori di pagine, niente plugin obbligatori, niente chiamate a servizi esterni.

## Installazione

1. In WordPress vai su **Aspetto → Temi → Aggiungi tema → Carica tema**, scegli `filo.zip` e premi **Installa ora**.
2. Premi **Attiva**.

All'attivazione il tema prepara il sito da solo, senza toccare quello che esiste già:

- crea le pagine **Insegna accesa**, **Bottega aperta**, **Chi c’è dietro** e **Contatti** (se mancano);
- crea la categoria **Attrezzi**, quella delle guide;
- mette nella pagina **Privacy e cookie** la bozza dell’informativa, che resta *in bozza*.

La home usa il template `front-page.php`: in **Impostazioni → Lettura** puoi lasciare «Gli ultimi articoli».

## Aggiornamenti

Dalla versione 1.0.2 il tema si aggiorna da solo. Controlla il file `tema/version.json` nel repository GitHub `sagiambe-code/filo`: quando lì compare una versione più nuova, WordPress la mostra in **Bacheca → Aggiornamenti**, come per i temi ufficiali. Con gli aggiornamenti automatici attivi (**Aspetto → Temi → Filo → Abilita gli aggiornamenti automatici**) la installa senza che tu faccia nulla, di solito entro dodici ore; per averla subito basta premere **Aggiorna** tra gli aggiornamenti.

Le impostazioni di Personalizza, i racconti, le guide e le pagine non vengono toccati: cambia solo il codice del tema.

## Cosa si modifica, e dove

| Cosa | Dove |
| --- | --- |
| Email, numero, WhatsApp, social, «● Bottega aperta» in testata, descrizione per Google | **Aspetto → Personalizza → Filo** |
| L’indirizzo che riceve i messaggi del modulo | **Personalizza → Filo**, campo «Email che riceve i messaggi». Se è vuoto, arrivano all’email di amministrazione |
| I lavori | **Racconti → Aggiungi racconto** |
| Le guide di Bottega aperta | **Articoli → Aggiungi articolo**, nella categoria **Attrezzi** |
| L’informativa privacy | **Pagine → Privacy e cookie** |
| L’icona del sito nella scheda del browser | **Personalizza → Identità del sito**. Se non scegli nulla, c’è la lampadina |
| I testi delle pagine principali (home, Insegna accesa, Bottega aperta, Chi c’è dietro, Contatti) | Nel tema, nei file `front-page.php` e `page-*.php` |

I testi delle pagine principali stanno nel tema perché fanno parte del disegno: ogni frase ha il suo posto nella griglia. Il contenuto che scrivi nell’editor di quelle quattro pagine non viene mostrato.

## I racconti (Lavori)

Ogni racconto ha il suo indirizzo, `filobottega.it/lavori/nome-del-racconto/`, e l’elenco sta in `filobottega.it/lavori/`.

- **Finché non pubblichi almeno un racconto, la voce «Lavori» nel menu e la sezione in home non compaiono.** Quando ne pubblichi uno, appaiono da sole.
- Un racconto nuovo parte già con la traccia della bottega: *Il prima, Il problema*, una citazione, *Cosa abbiamo tolto, Cosa è rimasto, L’errore utile*. I titoletti (Titolo 3) diventano le etichette rosse.
- Nel riquadro **Dettagli del racconto**, a destra: cliente, cosa ha fatto la bottega, indirizzo del sito e didascalia della foto.
- La **foto in evidenza** diventa la polaroid. Meglio orizzontale, almeno 1200 × 750 pixel.
- L’**estratto** è la riga che compare nell’elenco e in home.

## Le guide (Bottega aperta)

Gli articoli nella categoria **Attrezzi** compaiono come schede nella pagina Bottega aperta. Finché non ce n’è nessuno, si vede la guida sulla scheda Google come «in preparazione». L’estratto dell’articolo è il testo della scheda.

## Il modulo dei contatti

Il modulo, in home e nella pagina Contatti, spedisce una mail con le funzioni di WordPress: niente plugin, nessun messaggio salvato nel database. La risposta va direttamente a chi ha scritto, perché il messaggio ha il suo indirizzo come «Rispondi a».

C’è una trappola invisibile per i robot e un controllo sul tempo: chi invia in meno di tre secondi non è una persona.

**Consiglio:** dopo l’attivazione, mandati un messaggio di prova. Se non arriva, controlla lo spam; se ancora non arriva, su Aruba conviene installare un plugin SMTP (per esempio *WP Mail SMTP*) collegato alla casella ciao@filobottega.it.

## Dati per Google e per le intelligenze artificiali

In home, in Chi c’è dietro, in Contatti e in Insegna accesa il tema aggiunge i dati strutturati (schema.org, tipo *ProfessionalService*): nome, descrizione, contatti, zona servita, fondatore e la proposta Insegna accesa. Si aggiornano da soli con i valori di **Personalizza → Filo**.

## Prima del lancio

- Completa e fai verificare l’informativa (**Pagine → Privacy e cookie**), poi pubblicala: il link nel piè di pagina funziona solo quando è pubblica.
- Crea la casella **ciao@filobottega.it** su Aruba.
- In **Impostazioni → Lettura** togli la spunta a «Scoraggia i motori di ricerca».
- Fai il test «Ti trovano?» sul tuo stesso sito.

## Com’è fatto

```
filo/
├── style.css               stili e font (Inter Tight, Literata, JetBrains Mono, nel tema)
├── functions.php           supporti del tema, stili, descrizioni, pulizie
├── header.php / footer.php testata (grande in home, compatta altrove) e piè di pagina
├── front-page.php          la home
├── page-insegna-accesa.php
├── page-bottega-aperta.php il test «Ti trovano?» e le guide
├── page-chi-ce-dietro.php
├── page-contatti.php       con il modulo vero
├── page-privacy.php        l’informativa, testo dalla bacheca
├── archive-racconto.php    Lavori: l’elenco
├── single-racconto.php     un racconto
├── single.php              una guida
├── page.php, index.php, 404.php
├── template-parts/         racconto in home, schede delle guide
├── inc/
│   ├── helpers.php         menu, logo, link
│   ├── customizer.php      Personalizza → Filo
│   ├── racconti.php        il tipo di contenuto «Racconto»
│   ├── contatti.php        il modulo
│   ├── schema.php          i dati strutturati
│   ├── attivazione.php     la preparazione automatica
│   ├── aggiornamenti.php   gli aggiornamenti da GitHub
│   └── privacy-bozza.html  la bozza dell’informativa
└── assets/                 font, script, icona
```

La luce (chiaro/scuro) e le spunte del test «Ti trovano?» restano nel browser di chi visita (localStorage): nessun cookie.

I font sono distribuiti con licenza SIL Open Font License; le licenze sono in `assets/fonts/`.
