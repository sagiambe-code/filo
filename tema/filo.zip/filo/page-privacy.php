<?php
/**
 * Informativa privacy e cookie. Il testo si modifica dalla bacheca
 * (Pagine → Privacy e cookie).
 *
 * @package Filo
 */

get_header();
while ( have_posts() ) :
	the_post();
	?>
<section style="padding: clamp(48px, 8vw, 104px) 0 clamp(32px, 5vw, 56px)">
<p class="m" style="margin: 0 0 24px; color: var(--mute)"><?php the_title(); ?></p>
<h1 class="h" style="margin: 0; font-size: clamp(40px, 5.6vw, 80px); line-height: .95; font-weight: 600; letter-spacing: -.04em">Cosa succede<br>ai tuoi dati.</h1>
</section>
<section style="border-top: 1px solid var(--ink); padding: 48px 0 80px">
<div class="prose privacy" style="max-width: 720px">
<?php the_content(); ?>
<p class="m" style="color: var(--mute)">Ultimo aggiornamento: <?php echo esc_html( date_i18n( 'j F Y', get_the_modified_time( 'U' ) ) ); ?></p>
</div>
</section>
	<?php
endwhile;
get_footer();
