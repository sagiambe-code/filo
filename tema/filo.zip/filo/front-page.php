<?php
/**
 * Home.
 *
 * @package Filo
 */

get_header();
?>
<section id="top" style="display: flex; flex-wrap: wrap; gap: 40px; padding: clamp(40px, 7vw, 88px) 0 clamp(48px, 8vw, 96px); align-items: center">
<div style="flex: 1 1 380px; min-width: 0">
<p class="m" style="margin: 0 0 28px; color: var(--mute)">La bottega</p>
<h1 class="h" style="margin: 0; font-size: clamp(46px, 6.6vw, 100px); line-height: .9; font-weight: 600; letter-spacing: -.045em">Chi ti cerca,<br>ti trova.<br><span style="display: block; margin-top: .22em; font-family: 'Literata', Georgia, serif; font-style: italic; font-weight: 400; font-size: .5em; line-height: 1.1; letter-spacing: -.01em">Con le parole giuste.</span></h1>
<p style="margin: 40px 0 0; max-width: 34em; font-size: clamp(19px, 1.7vw, 22px); line-height: 1.5">Filo è una piccola bottega che costruisce siti per professionisti e non solo, ne scrive i testi e li accende dove la gente cerca davvero.</p>
<div style="display: flex; flex-wrap: wrap; gap: 12px; margin-top: 36px">
<a href="<?php echo esc_url( filo_url( 'insegna-accesa' ) ); ?>" class="btn fill m">Accendi l’insegna</a>
<a href="#scrivimi" class="btn m">Scrivi alla bottega</a>
</div>
</div>
<figure style="flex: 1 1 300px; min-width: 0; max-width: clamp(280px, 42vw, 560px); margin: 0 auto; position: relative">
<svg viewBox="0 0 420 470" width="100%" role="img" aria-label="Collage: una lampadina incisa davanti a una pagina di libro; il filamento è un filo vermiglio che esce dalla lampadina, scende con un’ansa e regge un cartellino con scritto, in codice, Aperto, entra pure" style="display: block">
<defs>
<clipPath id="fGlass"><path d="M142 200 C 100 170 92 120 112 92 C 132 62 208 62 228 92 C 248 120 240 170 198 200 L 196 214 L 144 214 Z"></path></clipPath>
<clipPath id="fSock"><rect x="144" y="214" width="52" height="32" rx="3"></rect></clipPath>
</defs>
<path d="M30 150 C 70 90 190 110 290 90 C 370 74 410 130 396 200 C 382 268 290 256 200 280 C 110 304 16 250 30 150 Z" fill="var(--swash)"></path>
<g transform="rotate(-4 220 220)">
<rect x="86" y="64" width="270" height="304" fill="#151411" opacity=".06"></rect>
<path d="M80 56 L 350 56 L 350 360 L 330 366 L 312 358 L 292 368 L 270 359 L 248 367 L 226 358 L 204 368 L 182 359 L 160 367 L 138 358 L 116 366 L 98 359 L 80 364 Z" fill="#FBF9F4" stroke="#151411" stroke-opacity=".18"></path>
<g fill="#151411" opacity=".13">
<rect x="104" y="84" width="222" height="3"></rect>
<rect x="104" y="97" width="222" height="3"></rect>
<rect x="104" y="110" width="222" height="3"></rect>
<rect x="104" y="123" width="222" height="3"></rect>
<rect x="104" y="136" width="222" height="3"></rect>
<rect x="104" y="149" width="222" height="3"></rect>
<rect x="104" y="162" width="222" height="3"></rect>
<rect x="104" y="175" width="222" height="3"></rect>
<rect x="104" y="188" width="140" height="3"></rect>
<rect x="118" y="214" width="208" height="3"></rect>
<rect x="104" y="227" width="222" height="3"></rect>
<rect x="104" y="240" width="222" height="3"></rect>
<rect x="104" y="253" width="222" height="3"></rect>
<rect x="104" y="266" width="222" height="3"></rect>
<rect x="104" y="279" width="222" height="3"></rect>
<rect x="104" y="292" width="222" height="3"></rect>
<rect x="104" y="305" width="222" height="3"></rect>
<rect x="104" y="318" width="222" height="3"></rect>
<rect x="104" y="331" width="96" height="3"></rect>
</g>
</g>
<g transform="translate(50 24)">
<path d="M142 200 C 100 170 92 120 112 92 C 132 62 208 62 228 92 C 248 120 240 170 198 200 L 196 214 L 144 214 Z" fill="#FBF9F4"></path>
<g clip-path="url(#fGlass)" fill="none" stroke="#151411" stroke-width=".9" stroke-opacity=".5">
<path d="M204 66 C 228 100 230 150 196 214"></path>
<path d="M210 66 C 234 100 236 150 202 214"></path>
<path d="M216 66 C 240 100 242 150 208 214"></path>
<path d="M222 66 C 246 100 248 150 214 214"></path>
<path d="M228 66 C 252 100 254 150 220 214"></path>
<path d="M234 66 C 258 100 260 150 226 214"></path>
</g>
<g fill="none" stroke="#151411" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
<path d="M142 200 C 100 170 92 120 112 92 C 132 62 208 62 228 92 C 248 120 240 170 198 200 L 196 214 L 144 214 Z"></path>
<path d="M124 112 C 128 96 140 86 154 82"></path>
<path d="M119 132 C 119 126 120 121 122 117"></path>
<rect x="144" y="214" width="52" height="32" rx="3" fill="#FBF9F4"></rect>
</g>
<g clip-path="url(#fSock)" stroke="#151411" stroke-width=".9" stroke-opacity=".55">
<path d="M182 214 L 182 246 M185 214 L 185 246 M188 214 L 188 246 M191 214 L 191 246 M194 214 L 194 246"></path>
</g>
<g fill="none" stroke="#151411" stroke-width="1.6" stroke-linecap="round">
<rect x="144" y="214" width="52" height="32" rx="3"></rect>
<path d="M146 222 L 194 226 M146 230 L 194 234 M146 238 L 194 242"></path>
</g>
<path d="M158 246 L 182 246 L 176 256 L 164 256 Z" fill="#151411"></path>
<path d="M162 214 L 160 162 C 148 142 176 132 168 120 C 158 106 188 100 181 118 C 176 132 196 142 182 162 L 180 214" fill="none" stroke="#D9432B" stroke-width="1.9" stroke-linecap="round"></path>
</g>
<path d="M220 280 C 218 318 172 322 168 352 C 164 384 200 400 230 410" fill="none" stroke="#D9432B" stroke-width="2" stroke-linecap="round"></path>
<g transform="translate(230 410) rotate(6)">
<path d="M-4 -24 L 138 -28 L 142 26 L 0 30 L -24 2 Z" fill="#EADFC8" stroke="#151411" stroke-width="1.2" stroke-linejoin="round"></path>
<circle cx="0" cy="1" r="6.5" fill="none" stroke="#151411" stroke-width=".8"></circle>
<circle cx="0" cy="1" r="3.2" fill="#F3F0E8" stroke="#151411" stroke-width="1"></circle>
<text x="16" y="-4" font-family="JetBrains Mono, monospace" font-size="12.5" fill="#3A3732">&lt;p&gt;Aperto,</text>
<text x="16" y="14" font-family="JetBrains Mono, monospace" font-size="12.5" fill="#3A3732">entra pure.&lt;/p&gt;</text>
</g>
<path d="M230 411 C 222 424 226 438 240 443" fill="none" stroke="#D9432B" stroke-width="2" stroke-linecap="round"></path>
</svg>
<figcaption style="font-style: italic; font-size: 17px; color: var(--mute); padding: 6px 0 0; text-align: right">Fi·lo, s.m. – quello che tiene accesa la lampadina.</figcaption>
</figure>
</section>

<section id="piazza" style="border-top: 1px solid var(--ink); padding: 64px 0 88px">
<p class="m" style="margin: 0 0 48px; color: var(--mute); text-align: center">La piazza e la casa</p>
<div class="pc-top" style="position: relative; max-width: 980px; margin: 0 auto">
<svg class="thread-h" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true" style="position: absolute; inset: 0; width: 100%; height: 100%; overflow: visible; pointer-events: none">
<path d="M25 62 C 26 76, 66 78, 75 64 C 84 90, 52 84, 50 100" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke"></path>
</svg>
<svg class="thread-v" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true" style="position: absolute; inset: 0; width: 100%; height: 100%; overflow: visible; pointer-events: none">
<path d="M50 29 C 26 33, 74 41, 50 46 M50 87 C 40 92, 60 96, 50 100" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke"></path>
</svg>
<div class="pc-cols" style="position: relative; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 40px 96px; padding-bottom: 150px; text-align: center">
<div>
<h2 class="h" style="margin: 0 0 14px; font-size: clamp(30px, 3.6vw, 46px); line-height: 1; font-weight: 600">La piazza</h2>
<p style="margin: 0 auto; max-width: 19em; font-size: 19px; line-height: 1.55">I social sono la piazza: ci si incontra, ci si mostra, si guarda chi passa. È bello starci, ma non è casa tua.</p>
</div>
<div>
<h2 class="h" style="margin: 0 0 14px; font-size: clamp(30px, 3.6vw, 46px); line-height: 1; font-weight: 600">La casa</h2>
<p style="margin: 0 auto; max-width: 19em; font-size: 19px; line-height: 1.55">Chi ti vuole trovare davvero ha bisogno di un indirizzo. Uno spazio tuo, per raccontare la tua storia con calma, che resta tuo anche quando la piazza cambia.</p>
</div>
</div>
</div>
<div style="display: flex; flex-direction: column; align-items: center; text-align: center">
<svg viewBox="0 0 24 74" width="22" height="68" aria-hidden="true" style="display: block; overflow: visible"><path class="glass" d="M12 0 C 20 0 24 7 24 15 C 24 23 19 28 17.5 33 L 17.5 38 L 6.5 38 L 6.5 33 C 5 28 0 23 0 15 C 0 7 4 0 12 0 Z" fill="var(--accent)" transform="translate(0 74) scale(1 -1)"></path><rect x="6.5" y="0" width="11" height="34.5" fill="currentColor"></rect><rect x="6.5" y="22" width="11" height="1.6" fill="var(--paper)"></rect><rect x="6.5" y="27" width="11" height="1.6" fill="var(--paper)"></rect></svg>
<p class="h" style="margin: 36px auto 0; max-width: 16em; padding: 0 12px; box-sizing: border-box; overflow-wrap: break-word; font-size: clamp(22px, 5.4vw, 42px); line-height: 1.15; font-weight: 600; letter-spacing: -.025em">La bottega costruisce la tua casa, e ci accende l’insegna.</p>
<a href="#insegna" class="m" style="margin-top: 28px; border-bottom: 1px solid var(--accent); padding-bottom: 2px">Come si accende</a>
</div>
</section>

<section id="perche" style="border-top: 1px solid var(--ink); padding: 64px 0 80px">
<p class="m" style="margin: 0 0 14px; color: var(--mute)">Perché la bottega</p>
<h2 class="h" style="margin: 0 0 64px; max-width: 13em; font-size: clamp(34px, 4.4vw, 56px); line-height: 1; font-weight: 600">Un sito si fa in cinque minuti.<br>Un’insegna no.</h2>
<div class="pb-grid">
<div class="pb-item">
<h3 class="h" style="margin: 0 0 12px; font-size: 24px; font-weight: 600; line-height: 1.1">Non basta esserci,<br>bisogna farsi trovare</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.55">Un sito fatto in fretta esiste, ma nessuno lo vede. La bottega sistema anche la scheda Google e usa le parole che la gente cerca davvero.</p>
</div>
<div class="pb-item">
<h3 class="h" style="margin: 0 0 12px; font-size: 24px; font-weight: 600; line-height: 1.1">Parole tue,<br>non di serie</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.55">I testi generati in automatico vanno bene per tutti, quindi non parlano di nessuno. La bottega ascolta come lavori e lo racconta con la tua voce.</p>
</div>
<div class="pb-item">
<h3 class="h" style="margin: 0 0 12px; font-size: 24px; font-weight: 600; line-height: 1.1">Una persona, non un<br>pannello di controllo</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.55">Niente serate a sistemare il sito da solo. C’è una persona che risponde, anche su WhatsApp, e tiene accesa la luce.</p>
</div>
</div>
<p style="margin: 64px auto 0; max-width: 22em; padding: 0 12px; text-align: center; font-style: italic; font-size: clamp(21px, 2.2vw, 26px); line-height: 1.35">Gli attrezzi ce li hanno tutti. La mano no.</p>
</section>

<section id="insegna" style="border-top: 1px solid var(--ink); padding: 64px 0 80px; text-align: center">
<p class="m" style="margin: 0 0 14px; color: var(--mute)">La proposta della bottega</p>
<h2 class="h" style="margin: 0 0 18px; font-size: clamp(34px, 4.4vw, 56px); line-height: 1; font-weight: 600">Insegna accesa</h2>
<p style="margin: 0 auto 56px; max-width: 30em; font-size: 19px; line-height: 1.5">In una bottega l’insegna serve a dire a chi passa che sei aperto. Online è lo stesso, solo che la strada è uno schermo: per farti trovare da chi ti sta già cercando.</p>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 40px 48px; max-width: 980px; margin: 0 auto">
<div style="display: flex; flex-direction: column; align-items: center; gap: 12px">
<span aria-hidden="true" style="width: 32px; height: 2px; background: var(--accent)"></span>
<h3 class="h" style="margin: 0; font-size: 24px; font-weight: 600; line-height: 1.1">Il sito,<br>scritto bene</h3>
<p style="margin: 0; max-width: 17em; font-size: 17px; line-height: 1.5">Una vetrina curata, poche pagine con le parole giuste e le tue foto vere.</p>
</div>
<div style="display: flex; flex-direction: column; align-items: center; gap: 12px">
<span aria-hidden="true" style="width: 32px; height: 2px; background: var(--accent)"></span>
<h3 class="h" style="margin: 0; font-size: 24px; font-weight: 600; line-height: 1.1">La scheda Google,<br>in ordine</h3>
<p style="margin: 0; max-width: 17em; font-size: 17px; line-height: 1.5">Su Google, su Maps e nelle risposte delle intelligenze artificiali: orari, foto e recensioni come si deve.</p>
</div>
<div style="display: flex; flex-direction: column; align-items: center; gap: 12px">
<span aria-hidden="true" style="width: 32px; height: 2px; background: var(--accent)"></span>
<h3 class="h" style="margin: 0; font-size: 24px; font-weight: 600; line-height: 1.1">La luce<br>sempre accesa</h3>
<p style="margin: 0; max-width: 17em; font-size: 17px; line-height: 1.5">Un piccolo canone per tenere tutto aggiornato, senza pensarci.</p>
</div>
</div>
<a href="<?php echo esc_url( filo_url( 'insegna-accesa' ) ); ?>" class="btn m" style="margin-top: 56px">Scopri Insegna accesa</a>
</section>


<section style="border-top: 1px solid var(--line); padding: 56px 0 72px">
<p class="m" style="margin: 0 0 36px; color: var(--mute); text-align: center">Come si lavora</p>
<ol style="list-style: none; margin: 0; padding: 0; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 32px">
<li style="border-top: 2px solid var(--ink); padding-top: 18px">
<p class="h" style="margin: 0 0 10px; font-size: 40px; font-weight: 600; color: var(--accent); line-height: 1">01</p>
<h3 class="h" style="margin: 0 0 8px; font-size: 21px; font-weight: 600">Un caffè</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Anche a distanza. Racconti cosa fai, e qui si ascolta più di quanto si parli.</p>
</li>
<li style="border-top: 2px solid var(--ink); padding-top: 18px">
<p class="h" style="margin: 0 0 10px; font-size: 40px; font-weight: 600; color: var(--accent); line-height: 1">02</p>
<h3 class="h" style="margin: 0 0 8px; font-size: 21px; font-weight: 600">Il progetto su carta</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Pagine, parole, tempi e preventivo, messi per iscritto prima di toccare il codice.</p>
</li>
<li style="border-top: 2px solid var(--ink); padding-top: 18px">
<p class="h" style="margin: 0 0 10px; font-size: 40px; font-weight: 600; color: var(--accent); line-height: 1">03</p>
<h3 class="h" style="margin: 0 0 8px; font-size: 21px; font-weight: 600">La costruzione</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Vedi il sito crescere su un indirizzo di prova, lo correggiamo insieme, poi si accende anche su Google.</p>
</li>
<li style="border-top: 2px solid var(--ink); padding-top: 18px">
<p class="h" style="margin: 0 0 10px; font-size: 40px; font-weight: 600; color: var(--accent); line-height: 1">04</p>
<h3 class="h" style="margin: 0 0 8px; font-size: 21px; font-weight: 600">Le chiavi</h3>
<p style="margin: 0; font-size: 17px; line-height: 1.5">Ricevi sito, accessi e un libretto d’istruzioni scritto per esseri umani. Se vuoi, la bottega tiene accesa la luce.</p>
</li>
</ol>
</section>



<?php get_template_part( 'template-parts/racconto', 'home' ); ?>

<section id="aperta" style="background: var(--card); border-top: 1px solid var(--ink); border-bottom: 1px solid var(--ink); padding: 56px clamp(16px, 4vw, 48px) 64px; margin: 0 calc(-1 * clamp(16px, 4vw, 40px))">
<div style="max-width: 1120px; margin: 0 auto">
<div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: flex-end; gap: 20px; margin-bottom: 40px">
<div>
<p class="m" style="margin: 0 0 14px; color: var(--mute)">Bottega aperta</p>
<h2 class="h" style="margin: 0; font-size: clamp(34px, 4.4vw, 56px); line-height: 1; font-weight: 600">Sul banco,<br>per chi passa.</h2>
</div>
<p style="margin: 0; max-width: 24em; font-size: 18px; line-height: 1.5">Attrezzi lasciati qui per chi ha un’attività da far trovare. Prendi quello che ti serve.</p>
</div>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; max-width: 760px">
<a href="<?php echo esc_url( filo_url( 'bottega-aperta' ) ); ?>" style="display: flex; flex-direction: column; gap: 10px; background: var(--paper); border: 1px solid var(--line); padding: 24px 24px 26px">
<span class="m" style="color: var(--accent)">Strumento</span>
<span class="h" style="font-size: 24px; font-weight: 600; line-height: 1.1">Ti trovano?</span>
<span style="font-size: 17px; line-height: 1.5; color: var(--mute)">Undici domande, cinque minuti, il telefono in mano.</span>
</a>
<a href="<?php echo esc_url( filo_url( 'bottega-aperta' ) ); ?>" style="display: flex; flex-direction: column; gap: 10px; background: var(--paper); border: 1px solid var(--line); padding: 24px 24px 26px">
<span class="m" style="color: var(--accent)">Guida</span>
<span class="h" style="font-size: 24px; font-weight: 600; line-height: 1.1">Come curare la tua scheda Google</span>
<span style="font-size: 17px; line-height: 1.5; color: var(--mute)">Orari, foto, recensioni: come tenerla in ordine.</span>
</a>
</div>
</div>
</section>

<section style="padding: clamp(56px, 9vw, 104px) 0 0; text-align: center">
<blockquote style="margin: 0 auto; max-width: 22em; font-style: italic; font-size: clamp(26px, 3.4vw, 40px); line-height: 1.25">«Un sito è una bottega con la porta sempre aperta: conviene che dentro ci sia qualcuno capace di dire buongiorno.»</blockquote>
</section>

<section id="scrivimi" style="padding: clamp(56px, 9vw, 104px) 0; display: flex; justify-content: center">
<div style="width: 100%; max-width: 620px; background: var(--frame); color: #151411; padding: clamp(28px, 5vw, 48px); box-shadow: 0 1px 2px rgba(0,0,0,.08), 0 14px 40px rgba(0,0,0,.1); transform: rotate(-.6deg)">
<p class="m" style="margin: 0 0 16px; color: #5E5A52">Scrivi alla bottega</p>
<h2 class="h" style="margin: 0 0 12px; font-size: clamp(32px, 4vw, 48px); line-height: 1; font-weight: 600">Lascia due righe.</h2>
<p style="margin: 0 0 28px; font-size: 18px; line-height: 1.5; color: #3A3732">Bastano il tuo nome, una mail e qualche parola su cosa ti serve. Risponde una persona, di solito entro un giorno.</p>
<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display: flex; flex-direction: column; gap: 18px; position: relative" data-form-el>
<?php filo_form_fields( 'home' ); filo_form_notice( 'home' ); ?>
<label class="m" style="color: #5E5A52; display: flex; flex-direction: column; gap: 4px">Nome<input class="field" type="text" name="nome" required maxlength="120"></label>
<label class="m" style="color: #5E5A52; display: flex; flex-direction: column; gap: 4px">Email<input class="field" type="email" name="email" required maxlength="160"></label>
<label class="m" style="color: #5E5A52; display: flex; flex-direction: column; gap: 4px">Di cosa si tratta<textarea class="field" name="messaggio" required maxlength="5000" rows="3" style="resize: vertical"></textarea></label>
<label style="display: flex; gap: 10px; align-items: flex-start; font-size: 16px; line-height: 1.45; color: #3A3732; cursor: pointer"><input type="checkbox" name="privacy" value="1" required style="width: 20px; height: 20px; margin: 2px 0 0; accent-color: #D9432B"><span>Ho letto l’<a href="<?php echo esc_url( filo_privacy_url() ); ?>" style="color: #151411; border-bottom: 1px solid #D9432B">informativa sulla privacy</a> e accetto che Filo usi questi dati solo per rispondermi.</span></label>
<div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 16px; margin-top: 8px">
<button type="submit" class="m" style="min-height: 44px; padding: 0 24px; background: #151411; color: #F3F0E8; border: 0; cursor: pointer">Invia</button>
<span style="font-style: italic; font-size: 17px; color: #3A3732">oppure: <a href="<?php echo esc_url( 'mailto:' . filo_opt( 'email' ) ); ?>" style="color: #151411; border-bottom: 1px solid #D9432B"><?php echo esc_html( filo_opt( 'email' ) ); ?></a> · <a href="<?php echo esc_url( filo_wa_url() ); ?>" style="color: #151411; border-bottom: 1px solid #D9432B">WhatsApp</a></span>
</div>
</form>
</div>
</section>
<?php
get_footer();
