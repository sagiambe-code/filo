<?php
/**
 * Elenco di articoli (archivi, ricerca, categorie).
 *
 * @package Filo
 */

get_header();
$filo_row = 'display: flex; flex-wrap: wrap; gap: 12px 48px; align-items: baseline; padding: 32px 0; border-bottom: 1px solid var(--line)';
if ( is_category( 'attrezzi' ) ) {
	$filo_title = 'Attrezzi della bottega';
} elseif ( is_search() ) {
	/* translators: termine cercato */
	$filo_title = sprintf( 'Hai cercato «%s»', get_search_query() );
} elseif ( is_archive() ) {
	$filo_title = wp_strip_all_tags( get_the_archive_title() );
} else {
	$filo_title = 'Dal banco';
}
?>
<section style="padding: clamp(48px, 8vw, 104px) 0 clamp(40px, 6vw, 72px)">
<h1 class="h" style="margin: 0; font-size: clamp(40px, 5.6vw, 80px); line-height: .95; font-weight: 600; letter-spacing: -.04em"><?php echo esc_html( $filo_title ); ?></h1>
</section>
<section style="border-top: 1px solid var(--ink)">
<?php if ( have_posts() ) : ?>
	<?php
	while ( have_posts() ) :
		the_post();
		?>
<a href="<?php the_permalink(); ?>" style="<?php echo esc_attr( $filo_row ); ?>">
<span class="m" style="flex: 0 0 200px; color: var(--mute)"><?php echo esc_html( filo_date() ); ?></span>
<span style="flex: 999 1 420px; min-width: 0">
<span class="h" style="display: block; font-size: clamp(26px, 3vw, 36px); font-weight: 600; line-height: 1.08; margin-bottom: 8px"><?php the_title(); ?></span>
<?php if ( has_excerpt() ) : ?><span style="display: block; font-size: 18px; line-height: 1.5; color: var(--mute)"><?php echo esc_html( get_the_excerpt() ); ?></span><?php endif; ?>
</span>
<span class="m" style="color: var(--accent)">Leggi</span>
</a>
	<?php endwhile; ?>
<div class="pager m"><span><?php previous_posts_link( 'Più recenti' ); ?></span><span><?php next_posts_link( 'Meno recenti' ); ?></span></div>
<?php else : ?>
<p style="padding: 48px 0 88px; font-size: 20px; font-style: italic; color: var(--mute)">Qui per ora non c’è niente. <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="font-style: normal; border-bottom: 1px solid var(--accent)">Torna alla home</a></p>
<?php endif; ?>
</section>
<?php
get_footer();
