<?php
/**
 * Pagina che non esiste.
 *
 * @package Filo
 */

get_header();
?>
<section style="padding: clamp(64px, 12vw, 160px) 0; text-align: center">
<p class="m" style="margin: 0 0 24px; color: var(--accent)">Errore 404</p>
<h1 class="h" style="margin: 0 auto; max-width: 12em; font-size: clamp(44px, 6.4vw, 92px); line-height: .92; font-weight: 600; letter-spacing: -.045em">Qui il filo<br>si è perso.</h1>
<p style="margin: 32px auto 0; max-width: 28em; font-size: clamp(19px, 1.7vw, 22px); line-height: 1.5">La pagina che cercavi non c’è, o ha cambiato indirizzo. Capita anche alle botteghe migliori.</p>
<div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 12px; margin-top: 36px">
<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn fill m">Torna alla home</a>
<a href="<?php echo esc_url( filo_url( 'contatti' ) ); ?>" class="btn m">Scrivi alla bottega</a>
</div>
</section>
<?php
get_footer();
