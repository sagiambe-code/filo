<?php
/**
 * Pagina semplice: titolo e testo dalla bacheca.
 *
 * @package Filo
 */

get_header();
while ( have_posts() ) :
	the_post();
	?>
<section style="padding: clamp(48px, 8vw, 104px) 0 clamp(32px, 5vw, 56px)">
<h1 class="h" style="margin: 0; font-size: clamp(40px, 5.6vw, 80px); line-height: .95; font-weight: 600; letter-spacing: -.04em"><?php the_title(); ?></h1>
</section>
<section style="border-top: 1px solid var(--ink); padding: 48px 0 80px">
<div class="prose" style="max-width: 720px">
<?php the_content(); ?>
</div>
</section>
	<?php
endwhile;
get_footer();
