<?php
/**
 * Filo – funzioni del tema.
 *
 * Il tema è costruito a mano sul prototipo di Filo – Bottega creativa.
 * Qui si caricano i pezzi: impostazioni, racconti, modulo contatti,
 * dati per Google e la preparazione automatica delle pagine.
 *
 * @package Filo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'FILO_VERSION', '1.0.9' );

require get_template_directory() . '/inc/helpers.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/racconti.php';
require get_template_directory() . '/inc/contatti.php';
require get_template_directory() . '/inc/schema.php';
require get_template_directory() . '/inc/attivazione.php';
require get_template_directory() . '/inc/aggiornamenti.php';

/**
 * Supporti del tema.
 */
function filo_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/editor.css' );
	add_image_size( 'filo-polaroid', 1200, 750, true );
}
add_action( 'after_setup_theme', 'filo_setup' );

/**
 * Il trattino lungo nei titoli: «Insegna accesa – Filo».
 */
add_filter( 'document_title_separator', function () {
	return '–';
} );

/**
 * In home il titolo è «Filo – Bottega creativa».
 */
add_filter( 'document_title_parts', function ( $parts ) {
	if ( is_front_page() ) {
		$parts = array( 'title' => get_bloginfo( 'name' ), 'tagline' => get_bloginfo( 'description' ) );
	}
	return $parts;
} );

/**
 * Stili e script. I font sono nel tema: nessuna chiamata a Google Fonts.
 */
function filo_assets() {
	wp_enqueue_style( 'filo', get_stylesheet_uri(), array(), FILO_VERSION );
	wp_enqueue_script( 'filo', get_template_directory_uri() . '/assets/js/main.js', array(), FILO_VERSION, array( 'in_footer' => true ) );
	// Il tema non usa lo stile dei blocchi in pagina, tranne negli articoli.
	if ( ! is_singular( array( 'post', 'racconto', 'page' ) ) ) {
		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'global-styles' );
	}
}
add_action( 'wp_enqueue_scripts', 'filo_assets', 20 );

/**
 * Precarica i due font principali, per evitare il salto del testo.
 */
add_action( 'wp_head', function () {
	$base = get_template_directory_uri() . '/assets/fonts/';
	foreach ( array( 'inter-tight-latin-wght-normal.woff2', 'literata-latin-opsz-normal.woff2' ) as $font ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $base . $font ) );
	}
}, 1 );

/**
 * La luce: legge la scelta salvata prima di disegnare la pagina,
 * così non c'è il lampo bianco quando si arriva con la luce spenta.
 */
add_action( 'wp_head', function () {
	echo "<script>try{var t=localStorage.getItem('filo-theme');if(t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches))document.documentElement.classList.add('is-dark')}catch(e){}</script>\n";
}, 2 );

/**
 * L'icona del sito: se non ne è stata scelta una in Personalizza, usa la lampadina.
 */
add_action( 'wp_head', function () {
	if ( ! has_site_icon() ) {
		printf( '<link rel="icon" href="%s" type="image/svg+xml">' . "\n", esc_url( get_template_directory_uri() . '/assets/favicon.svg' ) );
	}
} );

/**
 * Descrizione per i motori di ricerca, pagina per pagina.
 */
add_action( 'wp_head', function () {
	$desc = '';
	if ( is_front_page() ) {
		$desc = filo_opt( 'descrizione' );
	} elseif ( is_page( 'insegna-accesa' ) ) {
		$desc = 'Insegna accesa: il sito scritto bene, la scheda Google in ordine, l’inglese per chi arriva da fuori e la luce sempre accesa. Un’unica proposta, su misura.';
	} elseif ( is_page( 'bottega-aperta' ) ) {
		$desc = 'Attrezzi gratuiti per chi ha un’attività da far trovare: il test «Ti trovano?» e le guide della bottega.';
	} elseif ( is_page( 'chi-ce-dietro' ) ) {
		$desc = 'Chi c’è dietro Filo: Salvatore Giambelluca, web designer e scrittore siciliano.';
	} elseif ( is_page( 'contatti' ) ) {
		$desc = 'Scrivi alla bottega: due righe, una mail o un messaggio su WhatsApp.';
	} elseif ( is_singular() && has_excerpt() ) {
		$desc = get_the_excerpt();
	}
	if ( $desc ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( wp_strip_all_tags( $desc ) ) );
	}
}, 3 );

/**
 * Pulizie: niente emoji di WordPress, niente generatore in chiaro.
 */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );

/**
 * Estratti brevi, senza «[...]».
 */
add_filter( 'excerpt_length', function () {
	return 28;
} );
add_filter( 'excerpt_more', function () {
	return '…';
} );

/**
 * Niente commenti: il sito non ne ha bisogno.
 */
add_filter( 'comments_open', '__return_false', 20 );
add_filter( 'pings_open', '__return_false', 20 );
add_filter( 'comments_array', '__return_empty_array', 10 );
add_action( 'admin_menu', function () {
	remove_menu_page( 'edit-comments.php' );
} );
