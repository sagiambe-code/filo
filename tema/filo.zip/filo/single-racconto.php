<?php
/**
 * Un racconto per intero.
 *
 * @package Filo
 */

get_header();
while ( have_posts() ) :
	the_post();
	$filo_meta = array_filter( array( get_post_meta( get_the_ID(), 'filo_cliente', true ), get_post_meta( get_the_ID(), 'filo_lavoro', true ) ) );
	$filo_cap  = get_post_meta( get_the_ID(), 'filo_didascalia', true );
	$filo_site = get_post_meta( get_the_ID(), 'filo_sito', true );
	?>
<article style="padding: clamp(56px, 9vw, 112px) 0 0">
<p class="m" style="margin: 0 0 20px; text-align: center"><a href="<?php echo esc_url( get_post_type_archive_link( 'racconto' ) ); ?>" style="color: var(--mute)">Lavori</a></p>
<h1 class="h" style="margin: 0 auto 16px; max-width: 14em; text-align: center; font-size: clamp(36px, 5vw, 68px); line-height: .98; font-weight: 600; letter-spacing: -.04em"><?php the_title(); ?></h1>
<?php if ( $filo_meta ) : ?><p class="m" style="margin: 0 0 48px; text-align: center; color: var(--mute)"><?php echo esc_html( implode( ' · ', $filo_meta ) ); ?></p><?php endif; ?>

<div style="max-width: 680px; margin: 0 auto">
<?php if ( has_post_thumbnail() ) : ?>
<figure class="polaroid" style="margin: 0 0 48px; transform: rotate(-.8deg)">
<?php the_post_thumbnail( 'filo-polaroid' ); ?>
<?php if ( $filo_cap ) : ?><figcaption><?php echo esc_html( $filo_cap ); ?></figcaption><?php endif; ?>
</figure>
<?php endif; ?>

<div class="prose">
<?php the_content(); ?>
</div>

<div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 16px; margin-top: 48px; padding: 24px 0 72px; border-top: 1px solid var(--line)">
<?php if ( $filo_site ) : ?>
<a href="<?php echo esc_url( $filo_site ); ?>" class="m" style="border-bottom: 1px solid currentColor; padding-bottom: 2px">Visita il sito</a>
<?php else : ?>
<a href="<?php echo esc_url( get_post_type_archive_link( 'racconto' ) ); ?>" class="m" style="border-bottom: 1px solid currentColor; padding-bottom: 2px">Tutti i lavori</a>
<?php endif; ?>
<a href="<?php echo esc_url( filo_url( 'contatti' ) ); ?>" class="m" style="color: var(--accent)">Vuoi una storia così? Scrivi alla bottega</a>
</div>
</div>
</article>
	<?php
endwhile;
get_footer();
