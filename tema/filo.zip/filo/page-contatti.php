<?php
/**
 * Pagina «Contatti», con il modulo vero.
 *
 * @package Filo
 */

get_header();
?>
<section style="display: flex; flex-wrap: wrap; gap: 48px 72px; padding: clamp(48px, 8vw, 104px) 0 clamp(56px, 8vw, 104px); align-items: flex-start">
<div style="flex: 1 1 340px; min-width: 0">
<p class="m" style="margin: 0 0 24px; color: var(--mute)">Contatti</p>
<h1 class="h" style="margin: 0 0 32px; font-size: clamp(44px, 6.4vw, 92px); line-height: .92; font-weight: 600; letter-spacing: -.045em">Lascia<br>due righe.</h1>
<p style="margin: 0 0 40px; max-width: 26em; font-size: 20px; line-height: 1.5">Bastano il tuo nome, una mail e qualche parola su cosa ti serve. Risponde una persona, di solito entro un giorno.</p>
<dl style="margin: 0; display: flex; flex-direction: column; gap: 18px; max-width: 360px">
<div style="border-top: 1px solid var(--line); padding-top: 12px">
<dt class="m" style="color: var(--mute); margin-bottom: 6px">Per scrivere direttamente</dt>
<dd style="margin: 0; font-size: 20px"><a href="<?php echo esc_url( 'mailto:' . filo_opt( 'email' ) ); ?>" style="border-bottom: 1px solid var(--accent)"><?php echo esc_html( filo_opt( 'email' ) ); ?></a></dd>
</div>
<div style="border-top: 1px solid var(--line); padding-top: 12px">
<dt class="m" style="color: var(--mute); margin-bottom: 6px">Su WhatsApp</dt>
<dd style="margin: 0; font-size: 20px"><a href="<?php echo esc_url( filo_wa_url() ); ?>" style="border-bottom: 1px solid var(--accent)"><?php echo esc_html( filo_opt( 'telefono' ) ); ?></a></dd>
</div>
<div style="border-top: 1px solid var(--line); padding-top: 12px">
<dt class="m" style="color: var(--mute); margin-bottom: 6px">Dove</dt>
<dd style="margin: 0; font-size: 18px"><?php echo esc_html( filo_opt( 'luogo' ) ); ?>. Il caffè anche a distanza.</dd>
</div>
<div style="border-top: 1px solid var(--line); padding-top: 12px">
<dt class="m" style="color: var(--mute); margin-bottom: 6px">Altrove</dt>
<dd style="margin: 0; font-size: 18px"><?php filo_social(); ?></dd>
</div>
</dl>
</div>

<div id="modulo" style="flex: 999 1 480px; min-width: 0; max-width: 640px; scroll-margin-top: 24px; background: var(--frame); color: #151411; padding: clamp(24px, 4vw, 44px); box-shadow: 0 1px 2px rgba(0,0,0,.08), 0 14px 40px rgba(0,0,0,.1)">
<div data-form <?php echo 'ok' === filo_form_status() ? 'hidden' : ''; ?>>
<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display: flex; flex-direction: column; gap: 22px; position: relative" data-form-el>
<?php filo_form_fields( 'contatti' ); filo_form_notice( 'contatti' ); ?>
<fieldset style="border: 0; margin: 0; padding: 0">
<legend class="m" style="color: #5E5A52; padding: 0 0 12px">Che attività hai</legend>
<div style="display: flex; flex-wrap: wrap; gap: 8px">
<button type="button" class="chip" aria-pressed="false" data-topic style="font-family: 'JetBrains Mono', monospace; font-size: 12px; letter-spacing: .04em">Studio professionale</button>
<button type="button" class="chip" aria-pressed="false" data-topic style="font-family: 'JetBrains Mono', monospace; font-size: 12px; letter-spacing: .04em">Ospitalità</button>
<button type="button" class="chip" aria-pressed="false" data-topic style="font-family: 'JetBrains Mono', monospace; font-size: 12px; letter-spacing: .04em">Ristorazione</button>
<button type="button" class="chip" aria-pressed="false" data-topic style="font-family: 'JetBrains Mono', monospace; font-size: 12px; letter-spacing: .04em">Negozio o bottega</button>
<button type="button" class="chip" aria-pressed="false" data-topic style="font-family: 'JetBrains Mono', monospace; font-size: 12px; letter-spacing: .04em">Corsi ed esperienze</button>
<button type="button" class="chip" aria-pressed="false" data-topic style="font-family: 'JetBrains Mono', monospace; font-size: 12px; letter-spacing: .04em">Altro</button>
</div>
</fieldset>
<label class="m" style="color: #5E5A52; display: flex; flex-direction: column; gap: 4px">Nome<input class="field" type="text" name="nome" required maxlength="120" autocomplete="name"></label>
<label class="m" style="color: #5E5A52; display: flex; flex-direction: column; gap: 4px">Email<input class="field" type="email" name="email" required maxlength="160" autocomplete="email"></label>
<label class="m" style="color: #5E5A52; display: flex; flex-direction: column; gap: 4px">Due righe su di te<textarea class="field" name="messaggio" required maxlength="5000" rows="4" style="resize: vertical"></textarea></label>
<label style="display: flex; gap: 10px; align-items: flex-start; font-size: 16px; line-height: 1.45; color: #3A3732; cursor: pointer"><input type="checkbox" name="privacy" value="1" required style="width: 20px; height: 20px; margin: 2px 0 0; accent-color: #D9432B"><span>Ho letto l’<a href="<?php echo esc_url( filo_privacy_url() ); ?>" style="color: #151411; border-bottom: 1px solid #D9432B">informativa sulla privacy</a> e accetto che Filo usi questi dati solo per rispondermi.</span></label>
<div style="display: flex; flex-wrap: wrap; align-items: center; gap: 16px; margin-top: 4px">
<button type="submit" class="send m">Invia alla bottega</button>
<span style="font-style: italic; font-size: 16px; color: #5E5A52">Nessuna newsletter in regalo, promesso.</span>
</div>
</form>
</div>
<div data-thanks <?php echo 'ok' === filo_form_status() ? '' : 'hidden'; ?>>
<div style="padding: 24px 0; display: flex; flex-direction: column; gap: 16px" role="status">
<p class="m" style="margin: 0; color: #D9432B">Ricevuto</p>
<p class="h" style="margin: 0; font-size: 36px; font-weight: 600; line-height: 1.05">Grazie, le tue due righe<br>sono sul banco.</p>
<p style="margin: 0; font-size: 18px; line-height: 1.5; color: #3A3732">Ti risponde la bottega, di solito entro un giorno. Se è urgente, scrivi pure a <?php echo esc_html( filo_opt( 'email' ) ); ?> o su WhatsApp.</p>
<button type="button" class="m" data-again style="align-self: flex-start; min-height: 44px; background: none; border: 0; border-bottom: 1px solid currentColor; padding: 0; color: #151411; cursor: pointer">Scrivi un altro messaggio</button>
</div>
</div>
</div>
</section>
<?php
get_footer();
