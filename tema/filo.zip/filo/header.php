<?php
/**
 * Testata: in home la grande insegna, nelle altre pagine quella compatta.
 *
 * @package Filo
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip m" href="#contenuto">Vai al contenuto</a>
<div class="pg" data-root style="min-height: 100vh">
<div style="max-width: 1200px; margin: 0 auto; padding: 0 clamp(16px, 4vw, 40px)">

<?php if ( is_front_page() ) : ?>
<header style="padding: 22px 0 0">
<div class="topbar" style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 12px; padding-bottom: 14px; border-bottom: 1px solid var(--line)">
<span class="m sign" style="color: var(--mute)">Si fanno siti<span class="sep"> · </span><br class="mbr">si accendono insegne</span>
<div style="display: flex; align-items: center; gap: 16px">
<?php if ( filo_opt( 'aperta' ) ) : ?><span class="m open-status" style="color: var(--mute)"><span style="color: var(--accent)">●</span> Bottega aperta</span><?php endif; ?>
<button class="lamp" type="button" aria-label="Spegni la luce" data-lamp>
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path class="bulb" d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V16h5.2v-.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"></path></svg>
</button>
</div>
</div>
<div style="text-align: center; padding: 36px 0 22px; --L: clamp(72px, 8vw, 104px)">
<a href="#top" class="h" aria-label="Filo" style="font-size: var(--L); font-weight: 700; letter-spacing: -.055em; line-height: 1">F<svg class="logo-bulb" viewBox="0 0 24 74" aria-hidden="true"><path class="glass" d="M12 0 C 20 0 24 7 24 15 C 24 23 19 28 17.5 33 L 17.5 38 L 6.5 38 L 6.5 33 C 5 28 0 23 0 15 C 0 7 4 0 12 0 Z" fill="var(--accent)"></path><path d="M6 13 C 6 8.5 8 5.5 11 4.5" fill="none" stroke="var(--paper)" stroke-width="1.8" stroke-linecap="round"></path><rect x="6.5" y="39.5" width="11" height="34.5" fill="currentColor"></rect><rect x="6.5" y="44" width="11" height="1.6" fill="var(--paper)"></rect><rect x="6.5" y="49" width="11" height="1.6" fill="var(--paper)"></rect><rect x="6.5" y="54" width="11" height="1.6" fill="var(--paper)"></rect></svg><span style="letter-spacing: -.005em">l</span>o</a>
<p class="m" style="margin: 12px 0 0; color: var(--ink); font-size: 11.5px; letter-spacing: calc((var(--L) * 1.5736 - 108.76px) / 15); transform: translateX(calc(var(--L) * 0.0397 + ((var(--L) * 1.5736 - 108.76px) / 15 - 0.49px) / 2)); white-space: nowrap">Bottega creativa</p>
</div>
<div class="nav hnav" style="display: flex; flex-wrap: wrap; justify-content: center; padding: 4px 0; border-top: 1px solid var(--ink); border-bottom: 1px solid var(--ink)">
<button class="menubtn m" type="button" aria-expanded="false" aria-controls="menu" data-menu>Menu</button>
<nav id="menu" class="navlinks" aria-label="Menu">
<?php filo_nav_links(); ?>
</nav>
</div>
</header>
<?php else : ?>
<header class="nav" style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 16px; padding: 22px 0 18px; border-bottom: 1px solid var(--ink)">
<?php filo_logo( 44 ); ?>
<div class="ctl">
<button class="menubtn m" type="button" aria-expanded="false" aria-controls="menu" data-menu>Menu</button>
<button class="lamp" type="button" aria-label="Spegni la luce" data-lamp>
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path class="bulb" d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V16h5.2v-.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"></path></svg>
</button>
</div>
<nav id="menu" class="navlinks" aria-label="Menu">
<?php filo_nav_links(); ?>
</nav>
</header>
<?php endif; ?>

<main id="contenuto">
