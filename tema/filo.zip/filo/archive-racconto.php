<?php
/**
 * Lavori: l'elenco dei racconti.
 *
 * @package Filo
 */

get_header();
$filo_row = 'display: flex; flex-wrap: wrap; gap: 12px 48px; align-items: baseline; padding: 32px 0; border-bottom: 1px solid var(--line)';
?>
<section style="padding: clamp(48px, 8vw, 104px) 0 clamp(40px, 6vw, 72px)">
<p class="m" style="margin: 0 0 24px; color: var(--mute)">Lavori</p>
<h1 class="h" style="margin: 0; font-size: clamp(44px, 6.4vw, 92px); line-height: .92; font-weight: 600; letter-spacing: -.045em">Non una vetrina,<br>delle storie.</h1>
<p style="margin: 32px 0 0; max-width: 34em; font-size: clamp(19px, 1.7vw, 22px); line-height: 1.5">Ogni lavoro ha un prima, un problema e una soluzione, e qualche volta un errore da cui si è imparato. Qui si raccontano tutti e tre.</p>
</section>

<section aria-label="Elenco dei racconti" style="border-top: 1px solid var(--ink); margin-bottom: clamp(56px, 9vw, 104px)">
<?php
while ( have_posts() ) :
	the_post();
	$filo_meta = array_filter( array( get_post_meta( get_the_ID(), 'filo_cliente', true ), get_post_meta( get_the_ID(), 'filo_lavoro', true ) ) );
	?>
<a href="<?php the_permalink(); ?>" style="<?php echo esc_attr( $filo_row ); ?>">
<span class="m" style="flex: 0 0 200px; color: var(--mute)"><?php echo esc_html( implode( ' · ', $filo_meta ) ); ?></span>
<span style="flex: 999 1 420px; min-width: 0">
<span class="h" style="display: block; font-size: clamp(26px, 3vw, 36px); font-weight: 600; line-height: 1.08; margin-bottom: 8px"><?php the_title(); ?></span>
<?php if ( has_excerpt() ) : ?><span style="display: block; font-size: 18px; line-height: 1.5; color: var(--mute)"><?php echo esc_html( get_the_excerpt() ); ?></span><?php endif; ?>
</span>
<span class="m" style="color: var(--accent)">Leggi</span>
</a>
<?php endwhile; ?>
<a href="<?php echo esc_url( filo_url( 'contatti' ) ); ?>" style="display: flex; flex-wrap: wrap; gap: 12px 48px; align-items: baseline; padding: 32px 0; border-bottom: 1px solid var(--ink)">
<span class="m" style="flex: 0 0 200px; color: var(--accent)">Prossimo racconto</span>
<span style="flex: 999 1 420px; min-width: 0">
<span class="h" style="display: block; font-size: clamp(26px, 3vw, 36px); font-weight: 600; line-height: 1.08; margin-bottom: 8px">Questo posto è ancora libero</span>
<span style="display: block; font-size: 18px; line-height: 1.5; color: var(--mute)">Potrebbe essere la storia della tua bottega, del tuo studio o del tuo negozio.</span>
</span>
<span class="m" style="color: var(--accent)">Scrivi</span>
</a>
</section>
<?php
get_footer();
